"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Camera,
  Video,
  Edit,
  Palette,
  Radio,
  Share2,
  Plus,
  Edit3,
  Save,
  X,
  Eye,
  Heart,
  Sparkles,
  Upload,
  Trash2,
  ImageIcon,
  Grid3X3,
  List,
} from "lucide-react"

interface PortfolioItem {
  id: number
  title: string
  category: string
  description: string
  image: string
  video: string
  client: string
  date: string
  views: number
  likes: number
  tags: string[]
  featured: boolean
}

export default function PortfolioPage() {
  const [isAdminMode, setIsAdminMode] = useState(false)
  const [editingItem, setEditingItem] = useState<number | null>(null)
  const [addingNew, setAddingNew] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [animatedElements, setAnimatedElements] = useState<Set<string>>(new Set())

  const [portfolioItems, setPortfolioItems] = useState<PortfolioItem[]>([
    {
      id: 1,
      title: "Wedding Cinematic Video - Sarah & John",
      category: "videography",
      description: "Cinematic wedding video dengan drone shots dan storytelling yang emosional",
      image: "/placeholder.svg?height=300&width=400",
      video: "",
      client: "Sarah & John",
      date: "2024-01-15",
      views: 1250,
      likes: 89,
      tags: ["wedding", "cinematic", "drone"],
      featured: true,
    },
    {
      id: 2,
      title: "Brand Identity Design - Tech Startup",
      category: "design",
      description:
        "Complete brand identity design untuk startup teknologi termasuk logo, business card, dan guidelines",
      image: "/placeholder.svg?height=300&width=400",
      video: "",
      client: "TechStart Inc.",
      date: "2024-01-10",
      views: 890,
      likes: 67,
      tags: ["branding", "logo", "identity"],
      featured: false,
    },
    {
      id: 3,
      title: "Corporate Video Production",
      category: "videography",
      description: "Video profil perusahaan dengan interview karyawan dan showcase produk",
      image: "/placeholder.svg?height=300&width=400",
      video: "",
      client: "PT. Maju Bersama",
      date: "2024-01-05",
      views: 654,
      likes: 45,
      tags: ["corporate", "interview", "product"],
      featured: true,
    },
    {
      id: 4,
      title: "Product Photography - Fashion Brand",
      category: "photography",
      description: "Product photography untuk brand fashion dengan konsep minimalis dan clean",
      image: "/placeholder.svg?height=300&width=400",
      video: "",
      client: "Fashion Forward",
      date: "2023-12-28",
      views: 432,
      likes: 38,
      tags: ["product", "fashion", "minimalist"],
      featured: false,
    },
    {
      id: 5,
      title: "Music Video - Local Band",
      category: "video-editing",
      description: "Music video dengan heavy editing, color grading, dan visual effects",
      image: "/placeholder.svg?height=300&width=400",
      video: "",
      client: "The Rockers Band",
      date: "2023-12-20",
      views: 2100,
      likes: 156,
      tags: ["music", "effects", "color-grading"],
      featured: true,
    },
    {
      id: 6,
      title: "Live Streaming Setup - Conference",
      category: "live-streaming",
      description: "Multi-camera live streaming setup untuk konferensi internasional",
      image: "/placeholder.svg?height=300&width=400",
      video: "",
      client: "Global Conference 2023",
      date: "2023-12-15",
      views: 789,
      likes: 52,
      tags: ["live", "conference", "multi-camera"],
      featured: false,
    },
  ])

  const [newItem, setNewItem] = useState({
    title: "",
    category: "videography",
    description: "",
    client: "",
    tags: "",
    featured: false,
  })

  const [editForm, setEditForm] = useState<PortfolioItem | null>(null)

  const categories = [
    { id: "all", name: "Semua", icon: Sparkles },
    { id: "videography", name: "Videography", icon: Video },
    { id: "photography", name: "Photography", icon: Camera },
    { id: "video-editing", name: "Video Editing", icon: Edit },
    { id: "design", name: "Design", icon: Palette },
    { id: "live-streaming", name: "Live Streaming", icon: Radio },
    { id: "social-media", name: "Social Media", icon: Share2 },
  ]

  // Check if user is admin
  useEffect(() => {
    const adminStatus = localStorage.getItem("isAdmin")
    setIsAdminMode(adminStatus === "true")
  }, [])

  // Intersection Observer for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setAnimatedElements((prev) => new Set([...prev, entry.target.id]))
          }
        })
      },
      { threshold: 0.1, rootMargin: "50px" },
    )

    const elements = document.querySelectorAll("[data-animate]")
    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  const filteredItems =
    selectedCategory === "all" ? portfolioItems : portfolioItems.filter((item) => item.category === selectedCategory)

  const handleAddNew = () => {
    const newPortfolioItem: PortfolioItem = {
      id: Date.now(),
      title: newItem.title,
      category: newItem.category,
      description: newItem.description,
      client: newItem.client,
      tags: newItem.tags.split(",").map((tag) => tag.trim()),
      featured: newItem.featured,
      image: "/placeholder.svg?height=300&width=400",
      video: "",
      date: new Date().toISOString().split("T")[0],
      views: 0,
      likes: 0,
    }

    setPortfolioItems([newPortfolioItem, ...portfolioItems])
    setNewItem({
      title: "",
      category: "videography",
      description: "",
      client: "",
      tags: "",
      featured: false,
    })
    setAddingNew(false)
    alert("Portfolio item berhasil ditambahkan!")
  }

  const handleEditStart = (item: PortfolioItem) => {
    setEditForm({ ...item, tags: item.tags.join(", ") } as any)
    setEditingItem(item.id)
  }

  const handleEditSave = () => {
    if (!editForm) return

    const updatedItem: PortfolioItem = {
      ...editForm,
      tags: typeof editForm.tags === "string" ? editForm.tags.split(",").map((tag) => tag.trim()) : editForm.tags,
    }

    setPortfolioItems(portfolioItems.map((item) => (item.id === editForm.id ? updatedItem : item)))
    setEditingItem(null)
    setEditForm(null)
    alert("Portfolio item berhasil diupdate!")
  }

  const handleDelete = (itemId: number) => {
    if (confirm("Apakah Anda yakin ingin menghapus item ini?")) {
      setPortfolioItems(portfolioItems.filter((item) => item.id !== itemId))
      alert("Portfolio item berhasil dihapus!")
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, itemId?: number) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const imageUrl = event.target?.result as string

        if (itemId && editForm) {
          // Update edit form
          setEditForm({ ...editForm, image: imageUrl })
        } else if (itemId) {
          // Update existing item
          setPortfolioItems(portfolioItems.map((item) => (item.id === itemId ? { ...item, image: imageUrl } : item)))
        }
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Admin Mode Indicator */}
      {isAdminMode && (
        <div className="fixed top-4 right-4 z-50 bg-red-600 text-white px-4 py-2 rounded-full shadow-lg animate-pulse">
          <Edit3 className="h-4 w-4 inline mr-2" />
          Admin Mode Active
        </div>
      )}

      {/* Hero Section - Minimalist */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Our <span className="text-red-600">Portfolio</span>
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Koleksi karya terpilih yang menunjukkan kualitas dan kreativitas kami
            </p>

            {isAdminMode && (
              <Dialog open={addingNew} onOpenChange={setAddingNew}>
                <DialogTrigger asChild>
                  <Button className="mb-8 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600">
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Portfolio
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Tambah Portfolio Baru</DialogTitle>
                    <DialogDescription>Isi informasi untuk menambah item portfolio baru</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Judul *</Label>
                      <Input
                        id="title"
                        value={newItem.title}
                        onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                        placeholder="Judul portfolio"
                      />
                    </div>
                    <div>
                      <Label htmlFor="category">Kategori *</Label>
                      <select
                        id="category"
                        value={newItem.category}
                        onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                      >
                        {categories.slice(1).map((cat) => (
                          <option key={cat.id} value={cat.id}>
                            {cat.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label htmlFor="client">Klien</Label>
                      <Input
                        id="client"
                        value={newItem.client}
                        onChange={(e) => setNewItem({ ...newItem, client: e.target.value })}
                        placeholder="Nama klien"
                      />
                    </div>
                    <div>
                      <Label htmlFor="description">Deskripsi *</Label>
                      <Textarea
                        id="description"
                        value={newItem.description}
                        onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                        placeholder="Deskripsi portfolio"
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label htmlFor="tags">Tags (pisahkan dengan koma)</Label>
                      <Input
                        id="tags"
                        value={newItem.tags}
                        onChange={(e) => setNewItem({ ...newItem, tags: e.target.value })}
                        placeholder="tag1, tag2, tag3"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="featured"
                        checked={newItem.featured}
                        onChange={(e) => setNewItem({ ...newItem, featured: e.target.checked })}
                        className="rounded"
                      />
                      <Label htmlFor="featured">Featured Portfolio</Label>
                    </div>
                    <div className="flex space-x-2">
                      <Button onClick={handleAddNew} className="flex-1">
                        <Save className="h-4 w-4 mr-2" />
                        Simpan
                      </Button>
                      <Button variant="outline" onClick={() => setAddingNew(false)} className="flex-1">
                        <X className="h-4 w-4 mr-2" />
                        Batal
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            )}

            {/* Simple Stats */}
            <div className="flex justify-center space-x-8 text-sm text-gray-600">
              <div>
                <span className="font-semibold text-gray-900">{portfolioItems.length}</span> Projects
              </div>
              <div>
                <span className="font-semibold text-gray-900">
                  {portfolioItems.filter((item) => item.featured).length}
                </span>{" "}
                Featured
              </div>
              <div>
                <span className="font-semibold text-gray-900">
                  {portfolioItems.reduce((sum, item) => sum + item.views, 0)}
                </span>{" "}
                Views
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filter & View Controls */}
      <section className="py-6 bg-white sticky top-16 z-40 border-b border-gray-100">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {/* Category Filter */}
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full md:w-auto">
              <TabsList className="grid w-full grid-cols-3 md:grid-cols-7 bg-gray-50">
                {categories.map((category) => (
                  <TabsTrigger
                    key={category.id}
                    value={category.id}
                    className="data-[state=active]:bg-red-600 data-[state=active]:text-white transition-all duration-300 text-xs md:text-sm"
                  >
                    <category.icon className="h-3 w-3 md:h-4 md:w-4 mr-1" />
                    <span className="hidden sm:inline">{category.name}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>

            {/* View Mode Toggle */}
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant={viewMode === "grid" ? "default" : "outline"}
                onClick={() => setViewMode("grid")}
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant={viewMode === "list" ? "default" : "outline"}
                onClick={() => setViewMode("list")}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Grid/List */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {viewMode === "grid" ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredItems.map((item, index) => (
                <div
                  key={item.id}
                  id={`portfolio-${index}`}
                  data-animate
                  className={`transition-all duration-1000 ${
                    animatedElements.has(`portfolio-${index}`)
                      ? "opacity-100 translate-y-0"
                      : "opacity-0 translate-y-10"
                  }`}
                  style={{ transitionDelay: `${index * 50}ms` }}
                >
                  <Card className="border-gray-200 hover:shadow-lg transition-all duration-300 group relative overflow-hidden">
                    {item.featured && (
                      <Badge className="absolute top-3 left-3 bg-red-600 text-white z-10 text-xs">Featured</Badge>
                    )}

                    {isAdminMode && (
                      <div className="absolute top-3 right-3 z-10 flex space-x-1">
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-white/90 backdrop-blur-sm h-8 w-8 p-0"
                          onClick={() => handleEditStart(item)}
                        >
                          <Edit3 className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-white/90 backdrop-blur-sm text-red-600 hover:text-red-700 h-8 w-8 p-0"
                          onClick={() => handleDelete(item.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    )}

                    <div className="aspect-square bg-gray-100 relative overflow-hidden">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"></div>

                      {isAdminMode && (
                        <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleImageUpload(e, item.id)}
                            className="hidden"
                            id={`upload-${item.id}`}
                          />
                          <label htmlFor={`upload-${item.id}`}>
                            <Button
                              size="sm"
                              className="bg-white/90 text-gray-700 hover:bg-white cursor-pointer h-8 text-xs"
                              asChild
                            >
                              <span>
                                <Upload className="h-3 w-3 mr-1" />
                                Upload
                              </span>
                            </Button>
                          </label>
                        </div>
                      )}
                    </div>

                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className="text-xs">
                          {categories.find((cat) => cat.id === item.category)?.name}
                        </Badge>
                        <div className="flex items-center space-x-3 text-xs text-gray-500">
                          <div className="flex items-center">
                            <Eye className="h-3 w-3 mr-1" />
                            {item.views}
                          </div>
                          <div className="flex items-center">
                            <Heart className="h-3 w-3 mr-1" />
                            {item.likes}
                          </div>
                        </div>
                      </div>

                      <h3 className="font-semibold text-gray-900 mb-1 text-sm line-clamp-2">{item.title}</h3>

                      {item.client && <p className="text-xs text-gray-500 mb-2">{item.client}</p>}

                      <div className="flex flex-wrap gap-1">
                        {item.tags.slice(0, 2).map((tag, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs px-2 py-0">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredItems.map((item, index) => (
                <Card key={item.id} className="border-gray-200 hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-6">
                      <div className="w-32 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-gray-900 mb-1">{item.title}</h3>
                            <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              <span>{item.client}</span>
                              <span>{new Date(item.date).toLocaleDateString("id-ID")}</span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center">
                              <Eye className="h-4 w-4 mr-1" />
                              {item.views}
                            </div>
                            <div className="flex items-center">
                              <Heart className="h-4 w-4 mr-1" />
                              {item.likes}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline" className="text-xs">
                              {categories.find((cat) => cat.id === item.category)?.name}
                            </Badge>
                            {item.featured && <Badge className="bg-red-600 text-white text-xs">Featured</Badge>}
                          </div>
                          {isAdminMode && (
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline" onClick={() => handleEditStart(item)}>
                                <Edit3 className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-red-600 hover:text-red-700"
                                onClick={() => handleDelete(item.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {filteredItems.length === 0 && (
            <div className="text-center py-20">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Belum Ada Portfolio</h3>
              <p className="text-gray-600">Portfolio untuk kategori ini belum tersedia.</p>
            </div>
          )}
        </div>
      </section>

      {/* Edit Dialog */}
      {editingItem && editForm && (
        <Dialog open={!!editingItem} onOpenChange={() => setEditingItem(null)}>
          <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Portfolio</DialogTitle>
              <DialogDescription>Edit informasi portfolio item</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-title">Judul *</Label>
                <Input
                  id="edit-title"
                  value={editForm.title}
                  onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                  placeholder="Judul portfolio"
                />
              </div>

              <div>
                <Label htmlFor="edit-category">Kategori *</Label>
                <select
                  id="edit-category"
                  value={editForm.category}
                  onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  {categories.slice(1).map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="edit-client">Klien</Label>
                <Input
                  id="edit-client"
                  value={editForm.client}
                  onChange={(e) => setEditForm({ ...editForm, client: e.target.value })}
                  placeholder="Nama klien"
                />
              </div>

              <div>
                <Label htmlFor="edit-description">Deskripsi *</Label>
                <Textarea
                  id="edit-description"
                  value={editForm.description}
                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                  placeholder="Deskripsi portfolio"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="edit-tags">Tags (pisahkan dengan koma)</Label>
                <Input
                  id="edit-tags"
                  value={typeof editForm.tags === "string" ? editForm.tags : editForm.tags.join(", ")}
                  onChange={(e) => setEditForm({ ...editForm, tags: e.target.value } as any)}
                  placeholder="tag1, tag2, tag3"
                />
              </div>

              <div>
                <Label htmlFor="edit-image">Gambar Portfolio</Label>
                <div className="space-y-3">
                  <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                    <img
                      src={editForm.image || "/placeholder.svg"}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e)}
                      className="hidden"
                      id="edit-image-upload"
                    />
                    <label htmlFor="edit-image-upload">
                      <Button size="sm" variant="outline" className="cursor-pointer" asChild>
                        <span>
                          <ImageIcon className="h-4 w-4 mr-2" />
                          Ganti Gambar
                        </span>
                      </Button>
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="edit-featured"
                  checked={editForm.featured}
                  onChange={(e) => setEditForm({ ...editForm, featured: e.target.checked })}
                  className="rounded"
                />
                <Label htmlFor="edit-featured">Featured Portfolio</Label>
              </div>

              <div className="flex space-x-2">
                <Button onClick={handleEditSave} className="flex-1">
                  <Save className="h-4 w-4 mr-2" />
                  Simpan
                </Button>
                <Button variant="outline" onClick={() => setEditingItem(null)} className="flex-1">
                  <X className="h-4 w-4 mr-2" />
                  Batal
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
