"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Camera, Video, Edit, Palette, Radio, Share2, Check, Send, Plus, Edit3, Save, X, Sparkles } from "lucide-react"

export default function ServicesPage() {
  const [isAdminMode, setIsAdminMode] = useState(false)
  const [editingService, setEditingService] = useState<number | null>(null)
  const [orderDialog, setOrderDialog] = useState(false)
  const [selectedService, setSelectedService] = useState("")
  const [animatedElements, setAnimatedElements] = useState<Set<string>>(new Set())

  const [services, setServices] = useState([
    {
      id: 1,
      icon: <Edit className="h-12 w-12" />,
      title: "Video Editing",
      description: "Editing video profesional dengan kualitas cinematic dan storytelling yang menarik",
      features: [
        "Color Grading Professional",
        "Motion Graphics & Animation",
        "Audio Mixing & Sound Design",
        "Visual Effects & Compositing",
        "Multi-Camera Editing",
        "Green Screen & Chroma Key",
      ],
      duration: "3-7 hari kerja",
      popular: true,
    },
    {
      id: 2,
      icon: <Palette className="h-12 w-12" />,
      title: "Graphic Design",
      description: "Desain grafis kreatif untuk brand identity, marketing materials, dan digital content",
      features: [
        "Logo Design & Branding",
        "Print Design (Flyer, Poster, Brosur)",
        "Digital Design (Banner, Social Media)",
        "Packaging Design",
        "Corporate Identity",
        "UI/UX Design",
      ],
      duration: "2-5 hari kerja",
      popular: false,
    },
    {
      id: 3,
      icon: <Video className="h-12 w-12" />,
      title: "Videography",
      description: "Produksi video profesional dengan peralatan canggih dan tim berpengalaman",
      features: [
        "Wedding Videography",
        "Corporate Video",
        "Event Documentation",
        "Commercial & Advertisement",
        "Music Video Production",
        "Drone Videography",
      ],
      duration: "1-2 minggu",
      popular: true,
    },
    {
      id: 4,
      icon: <Camera className="h-12 w-12" />,
      title: "Photography",
      description: "Jasa fotografi profesional untuk berbagai kebutuhan personal dan komersial",
      features: [
        "Portrait & Fashion Photography",
        "Product Photography",
        "Event & Wedding Photography",
        "Corporate Photography",
        "Food Photography",
        "Real Estate Photography",
      ],
      duration: "1-3 hari kerja",
      popular: false,
    },
    {
      id: 5,
      icon: <Radio className="h-12 w-12" />,
      title: "Live Streaming",
      description: "Layanan live streaming profesional untuk event, webinar, dan konten digital",
      features: [
        "Multi-Camera Live Setup",
        "Professional Audio System",
        "Real-time Streaming to Multiple Platforms",
        "Interactive Features",
        "Technical Support 24/7",
        "Recording & Post-production",
      ],
      duration: "Sesuai durasi event",
      popular: false,
    },
    {
      id: 6,
      icon: <Share2 className="h-12 w-12" />,
      title: "Social Media Content",
      description: "Konten kreatif dan strategi media sosial untuk meningkatkan engagement brand",
      features: [
        "Content Strategy & Planning",
        "Visual Content Creation",
        "Video Content for Social Media",
        "Social Media Management",
        "Influencer Content",
        "Analytics & Reporting",
      ],
      duration: "Ongoing",
      popular: true,
    },
  ])

  const [orderForm, setOrderForm] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    description: "",
    timeline: "",
  })

  // Check if user is admin (in real app, this would be from authentication)
  useEffect(() => {
    const adminStatus = localStorage.getItem("isAdmin")
    setIsAdminMode(adminStatus === "true")
  }, [])

  // Intersection Observer for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setAnimatedElements((prev) => new Set([...prev, entry.target.id]))
          }
        })
      },
      { threshold: 0.1, rootMargin: "50px" },
    )

    const elements = document.querySelectorAll("[data-animate]")
    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Create WhatsApp message
    const message = `Halo! Saya ingin memesan layanan:

*Layanan:* ${orderForm.service}
*Nama:* ${orderForm.name}
*Email:* ${orderForm.email}
*Telepon:* ${orderForm.phone}
*Timeline:* ${orderForm.timeline}

*Deskripsi Kebutuhan:*
${orderForm.description}

Terima kasih!`

    const whatsappUrl = `https://wa.me/62895393181822?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")

    setOrderDialog(false)
    setOrderForm({
      name: "",
      email: "",
      phone: "",
      service: "",
      description: "",
      timeline: "",
    })
  }

  const saveService = (serviceId: number, updatedData: any) => {
    setServices(services.map((service) => (service.id === serviceId ? { ...service, ...updatedData } : service)))
    setEditingService(null)
    alert("Service berhasil diupdate!")
  }

  const addNewService = () => {
    const newService = {
      id: Date.now(),
      icon: <Plus className="h-12 w-12" />,
      title: "New Service",
      description: "Description for new service",
      features: ["Feature 1", "Feature 2", "Feature 3"],
      duration: "TBD",
      popular: false,
    }
    setServices([...services, newService])
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Admin Mode Indicator */}
      {isAdminMode && (
        <div className="fixed top-4 right-4 z-50 bg-red-600 text-white px-4 py-2 rounded-full shadow-lg animate-pulse">
          <Edit3 className="h-4 w-4 inline mr-2" />
          Admin Mode Active
        </div>
      )}

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-red-50 via-yellow-50 to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/5 to-blue-500/5"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center mr-4">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-5xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
                Layanan Kami
              </h1>
            </div>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Solusi multimedia profesional untuk semua kebutuhan kreatif Anda. Dari konsep hingga eksekusi, kami siap
              mewujudkan visi Anda.
            </p>
            {isAdminMode && (
              <Button
                onClick={addNewService}
                className="mb-8 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600"
              >
                <Plus className="h-4 w-4 mr-2" />
                Tambah Layanan Baru
              </Button>
            )}
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={service.id}
                id={`service-${index}`}
                data-animate
                className={`transition-all duration-1000 ${
                  animatedElements.has(`service-${index}`) ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <Card className="border-gray-200 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 group relative overflow-hidden h-full">
                  {service.popular && (
                    <Badge className="absolute top-4 right-4 bg-gradient-to-r from-red-500 to-red-600 text-white z-10">
                      Popular
                    </Badge>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                  {isAdminMode && editingService === service.id ? (
                    <div className="p-6 space-y-4">
                      <Input defaultValue={service.title} placeholder="Service Title" className="font-bold text-lg" />
                      <Textarea defaultValue={service.description} placeholder="Service Description" rows={3} />
                      <Input defaultValue={service.duration} placeholder="Duration" />
                      <div className="flex space-x-2">
                        <Button size="sm" onClick={() => saveService(service.id, {})}>
                          <Save className="h-4 w-4 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingService(null)}>
                          <X className="h-4 w-4 mr-1" />
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <CardHeader className="text-center relative z-10 pb-4">
                        <div
                          className={`mx-auto mb-4 p-4 bg-red-100 rounded-full text-red-600 w-fit transform group-hover:rotate-12 transition-transform duration-300`}
                        >
                          {service.icon}
                        </div>
                        <CardTitle className="text-2xl text-gray-900 group-hover:text-red-600 transition-colors duration-300 mb-2">
                          {service.title}
                        </CardTitle>
                        <CardDescription className="text-gray-600 text-base leading-relaxed">
                          {service.description}
                        </CardDescription>
                      </CardHeader>

                      <CardContent className="relative z-10 pt-0">
                        <div className="space-y-4 mb-6">
                          <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <span className="font-semibold text-gray-700">Durasi:</span>
                            <span className="text-blue-600 font-medium">{service.duration}</span>
                          </div>
                        </div>

                        <div className="mb-6">
                          <h4 className="font-semibold text-gray-900 mb-3">Yang Anda Dapatkan:</h4>
                          <ul className="space-y-2">
                            {service.features.map((feature, idx) => (
                              <li
                                key={idx}
                                className="flex items-center text-sm text-gray-600 group-hover:text-gray-700 transition-colors duration-300"
                              >
                                <Check className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                                {feature}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex space-x-2">
                          <Dialog open={orderDialog} onOpenChange={setOrderDialog}>
                            <DialogTrigger asChild>
                              <Button
                                className="flex-1 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 transition-all duration-300"
                                onClick={() => setSelectedService(service.title)}
                              >
                                <Send className="h-4 w-4 mr-2" />
                                Pesan Sekarang
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-md">
                              <DialogHeader>
                                <DialogTitle>Pesan Layanan: {selectedService}</DialogTitle>
                                <DialogDescription>
                                  Isi form di bawah ini dan kami akan menghubungi Anda via WhatsApp
                                </DialogDescription>
                              </DialogHeader>
                              <form onSubmit={handleOrderSubmit} className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label htmlFor="name">Nama *</Label>
                                    <Input
                                      id="name"
                                      required
                                      value={orderForm.name}
                                      onChange={(e) => setOrderForm({ ...orderForm, name: e.target.value })}
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="phone">Telepon *</Label>
                                    <Input
                                      id="phone"
                                      required
                                      value={orderForm.phone}
                                      onChange={(e) => setOrderForm({ ...orderForm, phone: e.target.value })}
                                    />
                                  </div>
                                </div>
                                <div>
                                  <Label htmlFor="email">Email *</Label>
                                  <Input
                                    id="email"
                                    type="email"
                                    required
                                    value={orderForm.email}
                                    onChange={(e) => setOrderForm({ ...orderForm, email: e.target.value })}
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="timeline">Timeline</Label>
                                  <Input
                                    id="timeline"
                                    placeholder="Kapan dibutuhkan?"
                                    value={orderForm.timeline}
                                    onChange={(e) => setOrderForm({ ...orderForm, timeline: e.target.value })}
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="description">Deskripsi Kebutuhan *</Label>
                                  <Textarea
                                    id="description"
                                    required
                                    rows={3}
                                    placeholder="Jelaskan detail kebutuhan Anda..."
                                    value={orderForm.description}
                                    onChange={(e) => setOrderForm({ ...orderForm, description: e.target.value })}
                                  />
                                </div>
                                <Button
                                  type="submit"
                                  className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600"
                                >
                                  <Send className="h-4 w-4 mr-2" />
                                  Kirim via WhatsApp
                                </Button>
                              </form>
                            </DialogContent>
                          </Dialog>

                          {isAdminMode && (
                            <Button size="sm" variant="outline" onClick={() => setEditingService(service.id)}>
                              <Edit3 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </>
                  )}
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Pertanyaan yang sering diajukan tentang layanan kami
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                question: "Berapa lama waktu pengerjaan proyek?",
                answer:
                  "Waktu pengerjaan bervariasi tergantung jenis layanan dan kompleksitas proyek. Umumnya 3-14 hari kerja.",
              },
              {
                question: "Apakah ada revisi gratis?",
                answer: "Ya, kami menyediakan 2-3 kali revisi gratis untuk setiap proyek sesuai dengan brief awal.",
              },
              {
                question: "Bagaimana sistem pembayaran?",
                answer: "Sistem pembayaran akan dibahas langsung via WhatsApp sesuai dengan kebutuhan proyek Anda.",
              },
              {
                question: "Apakah bisa konsultasi gratis?",
                answer: "Tentu! Kami menyediakan konsultasi gratis untuk membahas kebutuhan proyek Anda.",
              },
            ].map((faq, index) => (
              <Card key={index} className="border-gray-200">
                <CardHeader>
                  <CardTitle className="text-lg text-gray-900">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
