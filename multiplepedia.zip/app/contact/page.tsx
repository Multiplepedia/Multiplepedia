"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Mail,
  Phone,
  MapPin,
  Send,
  MessageCircle,
  Clock,
  CheckCircle,
  Sparkles,
  Instagram,
  Linkedin,
  Youtube,
  Globe,
} from "lucide-react"

export default function ContactPage() {
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
    service: "",
  })

  const [animatedElements, setAnimatedElements] = useState<Set<string>>(new Set())

  // Intersection Observer for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setAnimatedElements((prev) => new Set([...prev, entry.target.id]))
          }
        })
      },
      { threshold: 0.1, rootMargin: "50px" },
    )

    const elements = document.querySelectorAll("[data-animate]")
    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Save message to admin inbox (in real app, this would be an API call)
    const message = {
      id: Date.now(),
      ...contactForm,
      date: new Date().toISOString(),
      status: "unread",
    }

    // Store in localStorage for demo (in real app, send to backend)
    const existingMessages = JSON.parse(localStorage.getItem("adminMessages") || "[]")
    localStorage.setItem("adminMessages", JSON.stringify([message, ...existingMessages]))

    alert("Pesan Anda telah dikirim! Kami akan menghubungi Anda segera.")

    // Reset form
    setContactForm({
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
      service: "",
    })
  }

  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      info: "hello@visualcreativeproject.com",
      description: "Kirim email untuk pertanyaan detail",
    },
    {
      icon: Phone,
      title: "WhatsApp",
      info: "+62 895-3931-81822",
      description: "Chat langsung untuk konsultasi cepat",
    },
    {
      icon: MapPin,
      title: "Lokasi",
      info: "Jakarta, Indonesia",
      description: "Melayani seluruh Indonesia",
    },
    {
      icon: Clock,
      title: "Jam Operasional",
      info: "Senin - Sabtu, 09:00 - 18:00",
      description: "Response time: 1-2 jam",
    },
  ]

  const socialMedia = [
    { icon: Instagram, name: "Instagram", handle: "@visualcreativeproject", color: "pink" },
    { icon: Linkedin, name: "LinkedIn", handle: "Visual Creative Project", color: "blue" },
    { icon: Youtube, name: "YouTube", handle: "Visual Creative Project", color: "red" },
    { icon: Globe, name: "Website", handle: "visualcreativeproject.com", color: "gray" },
  ]

  const services = [
    "Video Editing",
    "Graphic Design",
    "Videography",
    "Photography",
    "Live Streaming",
    "Social Media Content",
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-red-50 via-yellow-50 to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/5 to-blue-500/5"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center mr-4">
                <MessageCircle className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-5xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
                Hubungi Kami
              </h1>
            </div>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Siap mewujudkan proyek kreatif Anda? Mari diskusikan kebutuhan Anda dengan tim profesional kami. Kami siap
              memberikan solusi terbaik untuk setiap tantangan multimedia.
            </p>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
              {[
                { number: "< 2 Jam", label: "Response Time", icon: Clock },
                { number: "24/7", label: "Support", icon: MessageCircle },
                { number: "500+", label: "Happy Clients", icon: CheckCircle },
                { number: "Free", label: "Konsultasi", icon: Sparkles },
              ].map((stat, index) => (
                <div
                  key={index}
                  className="text-center p-4 bg-white/80 backdrop-blur-sm rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                >
                  <stat.icon className="h-8 w-8 mx-auto mb-2 text-red-600" />
                  <div className="text-lg font-bold text-gray-900">{stat.number}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div
              id="contact-form"
              data-animate
              className={`transition-all duration-1000 ${
                animatedElements.has("contact-form") ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
              }`}
            >
              <Card className="shadow-2xl border-gray-200 hover:shadow-3xl transition-shadow duration-500">
                <CardHeader className="bg-gradient-to-r from-red-50 to-yellow-50">
                  <CardTitle className="text-2xl text-gray-900 flex items-center">
                    <Send className="h-6 w-6 mr-3 text-red-600" />
                    Kirim Pesan
                  </CardTitle>
                  <CardDescription className="text-base">
                    Isi form di bawah ini dan kami akan menghubungi Anda dalam 1-2 jam kerja
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="text-gray-700 font-medium">
                          Nama Lengkap *
                        </Label>
                        <Input
                          id="name"
                          required
                          value={contactForm.name}
                          onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                          className="border-gray-300 focus:border-red-500 focus:ring-red-500 transition-colors duration-300"
                          placeholder="Masukkan nama lengkap"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-gray-700 font-medium">
                          Nomor Telepon *
                        </Label>
                        <Input
                          id="phone"
                          required
                          value={contactForm.phone}
                          onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                          className="border-gray-300 focus:border-red-500 focus:ring-red-500 transition-colors duration-300"
                          placeholder="+62 812-3456-7890"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-gray-700 font-medium">
                        Email *
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        className="border-gray-300 focus:border-red-500 focus:ring-red-500 transition-colors duration-300"
                        placeholder="nama@email.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="service" className="text-gray-700 font-medium">
                        Layanan yang Diminati
                      </Label>
                      <select
                        id="service"
                        value={contactForm.service}
                        onChange={(e) => setContactForm({ ...contactForm, service: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-colors duration-300"
                      >
                        <option value="">Pilih layanan (opsional)</option>
                        {services.map((service) => (
                          <option key={service} value={service}>
                            {service}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="subject" className="text-gray-700 font-medium">
                        Subjek *
                      </Label>
                      <Input
                        id="subject"
                        required
                        value={contactForm.subject}
                        onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                        className="border-gray-300 focus:border-red-500 focus:ring-red-500 transition-colors duration-300"
                        placeholder="Subjek pesan Anda"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message" className="text-gray-700 font-medium">
                        Pesan *
                      </Label>
                      <Textarea
                        id="message"
                        required
                        rows={5}
                        value={contactForm.message}
                        onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                        className="border-gray-300 focus:border-red-500 focus:ring-red-500 transition-colors duration-300"
                        placeholder="Ceritakan detail proyek atau pertanyaan Anda..."
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
                    >
                      <Send className="h-5 w-5 mr-2" />
                      Kirim Pesan
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Information */}
            <div
              id="contact-info"
              data-animate
              className={`transition-all duration-1000 delay-300 ${
                animatedElements.has("contact-info") ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
              }`}
            >
              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">Informasi Kontak</h2>
                  <p className="text-gray-600 text-lg leading-relaxed">
                    Kami siap membantu mewujudkan visi kreatif Anda. Hubungi kami melalui berbagai channel yang
                    tersedia.
                  </p>
                </div>

                <div className="grid gap-6">
                  {contactInfo.map((contact, index) => (
                    <Card
                      key={index}
                      className="border-gray-200 hover:shadow-xl transition-all duration-500 transform hover:scale-105 group"
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div
                            className={`p-3 bg-red-100 rounded-full group-hover:bg-red-200 transition-colors duration-300`}
                          >
                            <contact.icon className={`h-6 w-6 text-red-600`} />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 text-lg mb-1 group-hover:text-gray-800 transition-colors duration-300">
                              {contact.title}
                            </h3>
                            <p className="text-gray-900 font-medium mb-1">{contact.info}</p>
                            <p className="text-gray-600 text-sm">{contact.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Social Media */}
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Follow Us</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {socialMedia.map((social, index) => (
                      <Card
                        key={index}
                        className="border-gray-200 hover:shadow-lg transition-all duration-300 transform hover:scale-105 group cursor-pointer"
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3">
                            <div
                              className={`p-2 bg-${social.color}-100 rounded-full group-hover:bg-${social.color}-200 transition-colors duration-300`}
                            >
                              <social.icon className={`h-5 w-5 text-${social.color}-600`} />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900 text-sm">{social.name}</p>
                              <p className="text-gray-600 text-xs">{social.handle}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                {/* Quick Contact */}
                <Card className="bg-gradient-to-r from-red-600 to-blue-600 text-white border-0">
                  <CardContent className="p-6 text-center">
                    <h3 className="text-xl font-bold mb-2">Butuh Respon Cepat?</h3>
                    <p className="mb-4 opacity-90">Hubungi langsung via WhatsApp untuk konsultasi instan</p>
                    <Button
                      size="lg"
                      className="bg-white text-red-600 hover:bg-gray-100 transform hover:scale-105 transition-all duration-300"
                      onClick={() => window.open("https://wa.me/62895393181822", "_blank")}
                    >
                      <Phone className="h-5 w-5 mr-2" />
                      Chat WhatsApp
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Pertanyaan yang sering diajukan seputar layanan dan proses kerja kami
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                question: "Berapa lama waktu response untuk pertanyaan?",
                answer:
                  "Kami berkomitmen untuk merespon setiap pertanyaan dalam waktu 1-2 jam pada jam kerja (Senin-Sabtu, 09:00-18:00).",
              },
              {
                question: "Apakah konsultasi awal gratis?",
                answer: "Ya, konsultasi awal untuk membahas kebutuhan proyek Anda sepenuhnya gratis tanpa komitmen.",
              },
              {
                question: "Bagaimana cara mengetahui estimasi biaya proyek?",
                answer:
                  "Setelah konsultasi awal, kami akan memberikan quotation detail berdasarkan scope dan kompleksitas proyek.",
              },
              {
                question: "Apakah melayani klien dari luar Jakarta?",
                answer:
                  "Ya, kami melayani klien dari seluruh Indonesia. Untuk proyek di luar Jakarta, akan ada penyesuaian untuk transportasi dan akomodasi.",
              },
              {
                question: "Bagaimana sistem pembayaran?",
                answer:
                  "Kami menggunakan sistem pembayaran bertahap: DP 50% untuk memulai proyek dan pelunasan setelah proyek selesai.",
              },
            ].map((faq, index) => (
              <Card key={index} className="border-gray-200 hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <CardTitle className="text-lg text-gray-900 flex items-center">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center mr-3">
                      <span className="text-red-600 font-bold text-sm">{index + 1}</span>
                    </div>
                    {faq.question}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
