"use client"
import { useState, useEffect } from "react"
import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Camera,
  Video,
  Edit,
  Palette,
  Send,
  Play,
  Star,
  Users,
  Award,
  Radio,
  Share2,
  CheckCircle,
  Phone,
  Mail,
  MapPin,
  Clock,
  Quote,
  User,
  Sparkles,
  Edit3,
  Save,
  X,
  Upload,
  ArrowUp,
  ArrowDown,
  Copy,
  Plus,
  Trash2,
  EyeOff,
  Move,
  PenTool,
} from "lucide-react"

export default function HomePage() {
  const [animatedElements, setAnimatedElements] = useState<Set<string>>(new Set())
  const [orderDialog, setOrderDialog] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [editMode, setEditMode] = useState(false)
  const [editingItem, setEditingItem] = useState<string | null>(null)
  const [indicatorPosition, setIndicatorPosition] = useState({ x: 16, y: 128 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })

  // Content state for editing
  const [content, setContent] = useState({
    hero: {
      badge: "Creative Multimedia Professional",
      title: "Multiplepedia",
      subtitle:
        "Menghadirkan solusi kreatif multimedia dengan kualitas profesional untuk kebutuhan bisnis dan personal Anda.",
      stats: [
        { number: "500+", label: "Proyek Selesai", icon: "Award" },
        { number: "200+", label: "Klien Puas", icon: "Users" },
        { number: "5+", label: "Tahun Pengalaman", icon: "Star" },
        { number: "24/7", label: "Support", icon: "CheckCircle" },
      ],
    },
    about: {
      title: "Tentang Para Pendiri",
      subtitle: "Mengenal sosok-sosok di balik Multiplepedia",
      founders: [
        {
          id: 1,
          name: "Muhammad Fathur Rohman",
          role: "Co-Founder & Creative Director",
          description:
            "Seorang creative professional dengan passion mendalam dalam dunia multimedia. Dengan pengalaman lebih dari 5 tahun, telah membantu ratusan klien mewujudkan visi kreatif mereka melalui videografi, fotografi, dan desain grafis yang memukau.",
          image: "/placeholder.svg?height=400&width=400",
        },
        {
          id: 2,
          name: "Fadil Nurrahman Fuadi",
          role: "Co-Founder & Technical Director",
          description:
            "Ahli teknologi multimedia dengan keahlian dalam video editing, motion graphics, dan live streaming. Berpengalaman dalam mengelola proyek-proyek besar dan memastikan kualitas teknis yang optimal untuk setiap karya yang dihasilkan.",
          image: "/placeholder.svg?height=400&width=400",
        },
      ],
      companyStats: {
        experience: { number: "5+", label: "Tahun Pengalaman" },
        projects: { number: "500+", label: "Proyek Selesai" },
        clients: { number: "200+", label: "Klien Puas" },
      },
    },
    services: {
      title: "Layanan Kami",
      subtitle: "Berbagai layanan kreatif untuk memenuhi kebutuhan multimedia Anda",
      items: [
        {
          id: 1,
          icon: "Video",
          title: "Videography",
          description: "Produksi video profesional untuk berbagai kebutuhan dengan kualitas cinematic",
          features: ["Wedding Video", "Corporate Video", "Event Documentation", "Commercial"],
        },
        {
          id: 2,
          icon: "Camera",
          title: "Photography",
          description: "Jasa fotografi profesional untuk momen spesial dan kebutuhan komersial",
          features: ["Portrait Photography", "Product Photography", "Event Photography", "Fashion Photography"],
        },
        {
          id: 3,
          icon: "Edit",
          title: "Video Editing",
          description: "Editing video profesional dengan kualitas cinematic dan storytelling menarik",
          features: ["Color Grading", "Motion Graphics", "Audio Mixing", "Visual Effects"],
        },
        {
          id: 4,
          icon: "Palette",
          title: "Graphic Design",
          description: "Desain grafis kreatif untuk brand identity dan marketing materials",
          features: ["Logo Design", "Branding", "Print Design", "Digital Design"],
        },
        {
          id: 5,
          icon: "Radio",
          title: "Live Streaming",
          description: "Layanan live streaming profesional untuk event dan webinar",
          features: ["Multi-Camera Setup", "Professional Audio", "Real-time Streaming", "Technical Support"],
        },
        {
          id: 6,
          icon: "Share2",
          title: "Social Media Content",
          description: "Konten kreatif untuk media sosial dan strategi digital marketing",
          features: ["Content Strategy", "Visual Content", "Video Content", "Social Media Management"],
        },
      ],
    },
    portfolio: {
      title: "Portfolio Karya",
      subtitle: "Koleksi proyek yang menunjukkan kualitas dan kreativitas kami",
      items: [
        {
          id: 1,
          title: "Wedding Cinematic Video",
          category: "Videography",
          image: "/placeholder.svg?height=300&width=400",
          client: "Sarah & John",
          description: "Cinematic wedding video dengan drone shots dan storytelling yang emosional",
        },
        {
          id: 2,
          title: "Brand Identity Design",
          category: "Design",
          image: "/placeholder.svg?height=300&width=400",
          client: "TechStart Inc.",
          description: "Complete brand identity design untuk startup teknologi",
        },
        {
          id: 3,
          title: "Corporate Video Production",
          category: "Videography",
          image: "/placeholder.svg?height=300&width=400",
          client: "PT. Maju Bersama",
          description: "Video profil perusahaan dengan interview karyawan",
        },
        {
          id: 4,
          title: "Product Photography",
          category: "Photography",
          image: "/placeholder.svg?height=300&width=400",
          client: "Fashion Forward",
          description: "Product photography dengan konsep minimalis dan clean",
        },
        {
          id: 5,
          title: "Music Video Production",
          category: "Video Editing",
          image: "/placeholder.svg?height=300&width=400",
          client: "The Rockers Band",
          description: "Music video dengan heavy editing dan visual effects",
        },
        {
          id: 6,
          title: "Live Event Streaming",
          category: "Live Streaming",
          image: "/placeholder.svg?height=300&width=400",
          client: "Global Conference 2024",
          description: "Multi-camera live streaming untuk konferensi internasional",
        },
      ],
    },
    testimonials: {
      title: "Testimoni Klien",
      subtitle: "Kepuasan klien adalah prioritas utama kami",
      items: [
        {
          name: "Sarah Johnson",
          role: "Bride",
          content:
            "Video pernikahan kami sangat cinematic dan emosional. Tim sangat profesional dan hasil melebihi ekspektasi!",
          rating: 5,
        },
        {
          name: "Ahmad Rahman",
          role: "CEO TechStart",
          content: "Brand identity yang dibuat sangat sesuai dengan visi perusahaan. Proses kerja sama sangat smooth.",
          rating: 5,
        },
        {
          name: "Lisa Permata",
          role: "Fashion Brand Owner",
          content:
            "Hasil foto produk sangat berkualitas dan meningkatkan penjualan online store kami secara signifikan.",
          rating: 5,
        },
      ],
    },
    contact: {
      title: "Hubungi Kami",
      subtitle: "Siap memulai proyek kreatif Anda? Mari diskusikan kebutuhan Anda",
      info: [
        {
          icon: "Phone",
          title: "WhatsApp",
          info: "+62 895-3931-81822",
          description: "Chat langsung untuk konsultasi cepat",
        },
        {
          icon: "Mail",
          title: "Email",
          info: "hello@multiplepedia.com",
          description: "Kirim email untuk pertanyaan detail",
        },
        {
          icon: "MapPin",
          title: "Lokasi",
          info: "Jakarta, Indonesia",
          description: "Melayani seluruh Indonesia",
        },
        {
          icon: "Clock",
          title: "Jam Operasional",
          info: "Senin - Sabtu, 09:00 - 18:00",
          description: "Response time: 1-2 jam",
        },
      ],
    },
  })

  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
    service: "",
  })
  const [orderForm, setOrderForm] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    description: "",
    timeline: "",
  })

  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set())
  const [showAddDialog, setShowAddDialog] = useState<{ type: string; category?: string } | null>(null)
  const [duplicateDialog, setDuplicateDialog] = useState<{ type: string; item: any } | null>(null)
  const [newItemForm, setNewItemForm] = useState({
    title: "",
    description: "",
    icon: "Sparkles",
    features: [""],
    category: "",
    client: "",
    image: "/placeholder.svg?height=300&width=400",
  })

  // Check admin status
  useEffect(() => {
    const adminStatus = localStorage.getItem("isAdmin")
    setIsAdmin(adminStatus === "true")
  }, [])

  // Load content from localStorage
  useEffect(() => {
    const savedContent = localStorage.getItem("websiteContent")
    if (savedContent) {
      setContent(JSON.parse(savedContent))
    }
  }, [])

  // Load indicator position from localStorage
  useEffect(() => {
    const savedPosition = localStorage.getItem("editIndicatorPosition")
    if (savedPosition) {
      setIndicatorPosition(JSON.parse(savedPosition))
    }
  }, [])

  // Save indicator position to localStorage
  useEffect(() => {
    localStorage.setItem("editIndicatorPosition", JSON.stringify(indicatorPosition))
  }, [indicatorPosition])

  // Cinematic intersection observer
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.target.id) {
            setAnimatedElements((prev) => new Set([...prev, entry.target.id]))
            entry.target.classList.add("visible")
          }
        })
      },
      { threshold: 0.1, rootMargin: "50px" },
    )

    const elements = document.querySelectorAll("[data-animate]")
    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  // Drag handlers for edit mode indicator
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    const rect = e.currentTarget.getBoundingClientRect()
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    })
  }

  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging) {
      const newX = e.clientX - dragOffset.x
      const newY = e.clientY - dragOffset.y

      // Keep within viewport bounds
      const maxX = window.innerWidth - 300 // Approximate width of indicator
      const maxY = window.innerHeight - 60 // Approximate height of indicator

      setIndicatorPosition({
        x: Math.max(16, Math.min(newX, maxX)),
        y: Math.max(16, Math.min(newY, maxY)),
      })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  useEffect(() => {
    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove)
      document.addEventListener("mouseup", handleMouseUp)
      return () => {
        document.removeEventListener("mousemove", handleMouseMove)
        document.removeEventListener("mouseup", handleMouseUp)
      }
    }
  }, [isDragging, dragOffset])

  // Icon mapping
  const getIcon = (iconName: string) => {
    const icons: { [key: string]: React.ReactNode } = {
      Video: <Video className="h-8 w-8" />,
      Camera: <Camera className="h-8 w-8" />,
      Edit: <Edit className="h-8 w-8" />,
      Palette: <Palette className="h-8 w-8" />,
      Radio: <Radio className="h-8 w-8" />,
      Share2: <Share2 className="h-8 w-8" />,
      Award: <Award className="h-8 w-8" />,
      Users: <Users className="h-8 w-8" />,
      Star: <Star className="h-8 w-8" />,
      CheckCircle: <CheckCircle className="h-8 w-8" />,
      Phone: <Phone className="h-6 w-6" />,
      Mail: <Mail className="h-6 w-6" />,
      MapPin: <MapPin className="h-6 w-6" />,
      Clock: <Clock className="h-6 w-6" />,
      Sparkles: <Sparkles className="h-8 w-8" />,
      PenTool: <PenTool className="h-8 w-8" />,
    }
    return icons[iconName] || <Sparkles className="h-8 w-8" />
  }

  // Edit functions
  const toggleEditMode = () => {
    setEditMode(!editMode)
    setEditingItem(null)
  }

  const saveAllContent = () => {
    localStorage.setItem("websiteContent", JSON.stringify(content))
    setEditMode(false)
    setEditingItem(null)
    alert("All changes saved successfully!")
  }

  const cancelAllEdits = () => {
    // Reload content from localStorage
    const savedContent = localStorage.getItem("websiteContent")
    if (savedContent) {
      setContent(JSON.parse(savedContent))
    }
    setEditMode(false)
    setEditingItem(null)
  }

  const updateContent = (section: string, field: string, value: any, index?: number, subField?: string) => {
    setContent((prev) => {
      const newContent = { ...prev }
      if (index !== undefined && subField) {
        // @ts-ignore
        newContent[section][field][index][subField] = value
      } else if (index !== undefined) {
        // @ts-ignore
        newContent[section][field][index] = value
      } else {
        // @ts-ignore
        newContent[section][field] = value
      }
      return newContent
    })
  }

  // Special function for updating founder data
  const updateFounder = (founderIndex: number, field: string, value: any) => {
    setContent((prev) => {
      const newContent = { ...prev }
      newContent.about.founders[founderIndex] = {
        ...newContent.about.founders[founderIndex],
        [field]: value,
      }
      return newContent
    })
  }

  // Special function for updating company stats
  const updateCompanyStats = (statKey: string, field: string, value: any) => {
    setContent((prev) => {
      const newContent = { ...prev }
      if (!newContent.about.companyStats) {
        newContent.about.companyStats = {
          experience: { number: "5+", label: "Tahun Pengalaman" },
          projects: { number: "500+", label: "Proyek Selesai" },
          clients: { number: "200+", label: "Klien Puas" },
        }
      }
      if (!newContent.about.companyStats[statKey]) {
        newContent.about.companyStats[statKey] = { number: "", label: "" }
      }
      newContent.about.companyStats[statKey][field] = value
      return newContent
    })
  }

  const handleImageUpload = (section: string, field: string, index?: number) => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = "image/*"
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        const reader = new FileReader()
        reader.onload = (event) => {
          const imageUrl = event.target?.result as string
          updateContent(section, field, imageUrl, index)
        }
        reader.readAsDataURL(file)
      }
    }
    input.click()
  }

  // Function to handle WhatsApp redirect with service info
  const handleWhatsAppRedirect = (serviceName?: string) => {
    const message = serviceName
      ? `Halo! Saya tertarik dengan layanan ${serviceName}. Bisa tolong berikan informasi lebih detail?`
      : `Halo! Saya tertarik dengan layanan Multiplepedia. Bisa tolong berikan informasi lebih detail?`

    const whatsappUrl = `https://wa.me/62895393181822?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const message = `Halo! Saya ingin memesan layanan:

*Layanan:* ${orderForm.service || "Belum dipilih"}
*Nama:* ${orderForm.name || ""}
*Email:* ${orderForm.email || ""}
*Telepon:* ${orderForm.phone || ""}
*Timeline:* ${orderForm.timeline || "Belum ditentukan"}

*Deskripsi Kebutuhan:*
${orderForm.description || ""}

Terima kasih!`

      const whatsappUrl = `https://wa.me/62895393181822?text=${encodeURIComponent(message)}`
      window.open(whatsappUrl, "_blank")

      setOrderDialog(false)
      setOrderForm({
        name: "",
        email: "",
        phone: "",
        service: "",
        description: "",
        timeline: "",
      })
    } catch (error) {
      console.error("Error submitting order:", error)
      alert("Terjadi kesalahan. Silakan coba lagi.")
    }
  }

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    try {
      // Format message for WhatsApp
      const message = `Halo! Saya ingin menghubungi Anda melalui website:

*Nama:* ${contactForm.name}
*Email:* ${contactForm.email}
*Telepon:* ${contactForm.phone}
*Layanan yang Diminati:* ${contactForm.service || "Tidak dipilih"}
*Subjek:* ${contactForm.subject}

*Pesan:*
${contactForm.message}

Terima kasih!`

      // Send to WhatsApp
      const whatsappUrl = `https://wa.me/62895393181822?text=${encodeURIComponent(message)}`
      window.open(whatsappUrl, "_blank")

      // Also save to localStorage for admin reference (optional)
      const messageData = {
        id: Date.now(),
        ...contactForm,
        date: new Date().toISOString(),
        status: "sent_to_whatsapp",
      }

      const existingMessages = JSON.parse(localStorage.getItem("adminMessages") || "[]")
      localStorage.setItem("adminMessages", JSON.stringify([messageData, ...existingMessages]))

      alert("Pesan Anda akan dikirim ke WhatsApp! Kami akan menghubungi Anda segera.")

      // Reset form
      setContactForm({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
        service: "",
      })
    } catch (error) {
      console.error("Error submitting contact:", error)
      alert("Terjadi kesalahan. Silakan coba lagi.")
    }
  }

  const scrollToSection = (sectionId: string) => {
    try {
      const element = document.getElementById(sectionId)
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" })
      }
    } catch (error) {
      console.error("Error scrolling to element:", error)
    }
  }

  const toggleCategory = (category: string) => {
    setExpandedCategories((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(category)) {
        newSet.delete(category)
      } else {
        newSet.add(category)
      }
      return newSet
    })
  }

  const getServicesByCategory = () => {
    const categories = ["Video Production", "Photography", "Design", "Digital Services"]
    return categories.reduce(
      (acc, category) => {
        acc[category] = content.services.items.filter((item) => {
          if (category === "Video Production") return ["Video", "Edit", "Radio"].includes(item.icon)
          if (category === "Photography") return item.icon === "Camera"
          if (category === "Design") return item.icon === "Palette"
          if (category === "Digital Services") return item.icon === "Share2"
          return false
        })
        return acc
      },
      {} as Record<string, any[]>,
    )
  }

  const getPortfolioByCategory = () => {
    const categories = ["Videography", "Photography", "Design", "Video Editing", "Live Streaming"]
    return categories.reduce(
      (acc, category) => {
        acc[category] = content.portfolio.items.filter((item) => item.category === category)
        return acc
      },
      {} as Record<string, any[]>,
    )
  }

  const addNewItem = (type: "service" | "portfolio") => {
    if (type === "service") {
      const newService = {
        id: Date.now(),
        icon: newItemForm.icon,
        title: newItemForm.title || "New Service",
        description: newItemForm.description || "Description for new service",
        features: newItemForm.features.filter((f) => f.trim() !== "") || ["Feature 1", "Feature 2", "Feature 3"],
      }
      setContent((prev) => ({
        ...prev,
        services: {
          ...prev.services,
          items: [...prev.services.items, newService],
        },
      }))
    } else if (type === "portfolio") {
      const newPortfolio = {
        id: Date.now(),
        title: newItemForm.title || "New Portfolio Item",
        category: newItemForm.category || "Design",
        image: newItemForm.image,
        client: newItemForm.client || "New Client",
        description: newItemForm.description || "Description for new portfolio item",
      }
      setContent((prev) => ({
        ...prev,
        portfolio: {
          ...prev.portfolio,
          items: [...prev.portfolio.items, newPortfolio],
        },
      }))
    }
    setShowAddDialog(null)
    setNewItemForm({
      title: "",
      description: "",
      icon: "Sparkles",
      features: [""],
      category: "",
      client: "",
      image: "/placeholder.svg?height=300&width=400",
    })
  }

  const duplicateItem = (type: "service" | "portfolio", item: any) => {
    const duplicatedItem = {
      ...item,
      id: Date.now(),
      title: `${item.title} (Copy)`,
    }

    if (type === "service") {
      setContent((prev) => ({
        ...prev,
        services: {
          ...prev.services,
          items: [...prev.services.items, duplicatedItem],
        },
      }))
    } else if (type === "portfolio") {
      setContent((prev) => ({
        ...prev,
        portfolio: {
          ...prev.portfolio,
          items: [...prev.portfolio.items, duplicatedItem],
        },
      }))
    }
    setDuplicateDialog(null)
  }

  const deleteItem = (type: "service" | "portfolio", itemId: number) => {
    if (confirm("Are you sure you want to delete this item?")) {
      if (type === "service") {
        setContent((prev) => ({
          ...prev,
          services: {
            ...prev.services,
            items: prev.services.items.filter((item) => item.id !== itemId),
          },
        }))
      } else if (type === "portfolio") {
        setContent((prev) => ({
          ...prev,
          portfolio: {
            ...prev.portfolio,
            items: prev.portfolio.items.filter((item) => item.id !== itemId),
          },
        }))
      }
    }
  }

  const moveItem = (type: "service" | "portfolio", itemId: number, direction: "up" | "down") => {
    const items = type === "service" ? content.services.items : content.portfolio.items
    const currentIndex = items.findIndex((item) => item.id === itemId)

    if ((direction === "up" && currentIndex > 0) || (direction === "down" && currentIndex < items.length - 1)) {
      const newItems = [...items]
      const targetIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1

      // Swap items
      ;[newItems[currentIndex], newItems[targetIndex]] = [newItems[targetIndex], newItems[currentIndex]]

      if (type === "service") {
        setContent((prev) => ({
          ...prev,
          services: { ...prev.services, items: newItems },
        }))
      } else {
        setContent((prev) => ({
          ...prev,
          portfolio: { ...prev.portfolio, items: newItems },
        }))
      }
    }
  }

  const addFeature = () => {
    setNewItemForm((prev) => ({
      ...prev,
      features: [...prev.features, ""],
    }))
  }

  const updateFeature = (index: number, value: string) => {
    setNewItemForm((prev) => ({
      ...prev,
      features: prev.features.map((f, i) => (i === index ? value : f)),
    }))
  }

  const removeFeature = (index: number) => {
    setNewItemForm((prev) => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index),
    }))
  }

  // Editable Text Component
  const EditableText = ({
    value,
    onChange,
    className = "",
    multiline = false,
    placeholder = "Click to edit...",
  }: {
    value: string
    onChange: (value: string) => void
    className?: string
    multiline?: boolean
    placeholder?: string
  }) => {
    const [isEditing, setIsEditing] = useState(false)
    const [tempValue, setTempValue] = useState(value)

    useEffect(() => {
      setTempValue(value)
    }, [value])

    const handleSave = () => {
      onChange(tempValue)
      setIsEditing(false)
    }

    const handleCancel = () => {
      setTempValue(value)
      setIsEditing(false)
    }

    if (!editMode) {
      return <span className={className}>{value}</span>
    }

    if (isEditing) {
      return (
        <div className="inline-block w-full">
          {multiline ? (
            <Textarea
              value={tempValue}
              onChange={(e) => setTempValue(e.target.value)}
              className={`${className} border-2 border-blue-500`}
              autoFocus
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSave()
                }
                if (e.key === "Escape") {
                  handleCancel()
                }
              }}
            />
          ) : (
            <Input
              value={tempValue}
              onChange={(e) => setTempValue(e.target.value)}
              className={`${className} border-2 border-blue-500`}
              autoFocus
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSave()
                }
                if (e.key === "Escape") {
                  handleCancel()
                }
              }}
            />
          )}
          <div className="flex gap-2 mt-2">
            <Button size="sm" onClick={handleSave} className="bg-green-600 hover:bg-green-700">
              <Save className="h-3 w-3 mr-1" />
              Save
            </Button>
            <Button size="sm" variant="outline" onClick={handleCancel}>
              <X className="h-3 w-3 mr-1" />
              Cancel
            </Button>
          </div>
        </div>
      )
    }

    return (
      <div
        className={`${className} ${editMode ? "cursor-pointer hover:bg-blue-50 hover:border-blue-300 border-2 border-dashed border-transparent p-1 rounded transition-all duration-200" : ""}`}
        onClick={() => editMode && setIsEditing(true)}
        title={editMode ? "Click to edit" : ""}
      >
        {value || placeholder}
        {editMode && <Edit3 className="inline-block h-4 w-4 ml-2 text-blue-500" />}
      </div>
    )
  }

  // Editable Image Component
  const EditableImage = ({
    src,
    alt,
    onChange,
    className = "",
  }: {
    src: string
    alt: string
    onChange: (src: string) => void
    className?: string
  }) => {
    const handleImageUpload = () => {
      const input = document.createElement("input")
      input.type = "file"
      input.accept = "image/*"
      input.onchange = (e) => {
        const file = (e.target as HTMLInputElement).files?.[0]
        if (file) {
          const reader = new FileReader()
          reader.onload = (event) => {
            const imageUrl = event.target?.result as string
            onChange(imageUrl)
          }
          reader.readAsDataURL(file)
        }
      }
      input.click()
    }

    return (
      <div className={`relative ${editMode ? "group" : ""}`}>
        <img src={src || "/placeholder.svg"} alt={alt} className={className} />
        {editMode && (
          <div
            className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer rounded-full"
            onClick={handleImageUpload}
          >
            <div className="bg-white rounded-lg p-3 flex items-center gap-2">
              <Upload className="h-4 w-4" />
              <span className="text-sm font-medium">Change Image</span>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="min-h-screen relative">
      {/* Admin Controls */}
      {isAdmin && (
        <div className="fixed top-4 right-4 z-50 flex gap-2">
          <Button
            onClick={toggleEditMode}
            className={`${editMode ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"} text-white shadow-lg`}
          >
            {editMode ? <EyeOff className="h-4 w-4 mr-2" /> : <Edit3 className="h-4 w-4 mr-2" />}
            {editMode ? "Exit Edit Mode" : "Edit Mode"}
          </Button>

          {editMode && (
            <>
              <Button onClick={saveAllContent} className="bg-green-600 hover:bg-green-700 text-white shadow-lg">
                <Save className="h-4 w-4 mr-2" />
                Save All
              </Button>
              <Button onClick={cancelAllEdits} variant="outline" className="shadow-lg bg-transparent">
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            </>
          )}
        </div>
      )}

      {/* Draggable Edit Mode Indicator */}
      {editMode && (
        <div
          className={`fixed z-40 bg-blue-600 text-white px-4 py-2 rounded-full shadow-lg animate-pulse select-none ${isDragging ? "cursor-grabbing" : "cursor-grab"}`}
          style={{
            left: `${indicatorPosition.x}px`,
            top: `${indicatorPosition.y}px`,
          }}
          onMouseDown={handleMouseDown}
        >
          <Move className="h-4 w-4 inline mr-2" />
          Edit Mode Active - Click any text or image to edit
        </div>
      )}

      {/* Motion Graphics Background */}
      <div className="motion-graphics">
        <div
          className="floating-shape shape-circle"
          style={{
            width: "60px",
            height: "60px",
            top: "15%",
            left: "10%",
            animation: "floatShape1 80s ease-in-out infinite",
          }}
        ></div>

        <div
          className="floating-shape shape-square"
          style={{
            width: "40px",
            height: "40px",
            top: "60%",
            right: "15%",
            animation: "floatShape2 95s ease-in-out infinite",
          }}
        ></div>

        <div
          className="floating-shape shape-square"
          style={{
            width: "30px",
            height: "30px",
            bottom: "40%",
            right: "10%",
            background: "linear-gradient(45deg, #7c3aed, #ec4899)",
            animation: "floatShape1 75s ease-in-out infinite reverse",
          }}
        ></div>
      </div>

      {/* Background Ornaments */}
      <div className="bg-ornaments">
        <div className="ornament ornament-1"></div>
        <div className="ornament ornament-2"></div>
        <div className="ornament ornament-3"></div>
      </div>

      {/* Moving Background Blur Effects */}
      <div className="bg-blur-effects">
        <div className="blur-element blur-crimson"></div>
        <div className="blur-element blur-amber"></div>
        <div className="blur-element blur-indigo"></div>
        <div className="blur-element blur-emerald"></div>
        <div className="blur-element blur-violet"></div>
        <div className="blur-element blur-rose"></div>
      </div>

      {/* Hero Section */}
      <section id="hero" className="min-h-screen flex items-center justify-center relative pt-20 overflow-hidden">
        <div className="container mx-auto px-6 lg:px-12 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            {/* Badge */}
            <div
              className="inline-flex items-center px-6 py-3 glass-effect rounded-full mb-8 shadow-lg border border-white/20 cinematic-entrance"
              data-animate
              id="hero-badge"
            >
              <Sparkles className="h-5 w-5 text-red-500 mr-3 animate-pulse-slow" />
              <EditableText
                value={content.hero.badge}
                onChange={(value) => updateContent("hero", "badge", value)}
                className="text-sm font-medium text-gray-700"
              />
            </div>

            {/* Main Title */}
            <h1
              className="text-5xl md:text-7xl lg:text-8xl font-bold mb-8 leading-tight cinematic-entrance"
              data-animate
              id="hero-title"
              style={{ animationDelay: "0.2s" }}
            >
              <EditableText
                value={content.hero.title}
                onChange={(value) => updateContent("hero", "title", value)}
                className="gradient-text-main"
              />
            </h1>

            {/* Subtitle */}
            <EditableText
              value={content.hero.subtitle}
              onChange={(value) => updateContent("hero", "subtitle", value)}
              className="text-xl md:text-2xl text-gray-600 mb-12 leading-relaxed max-w-3xl mx-auto cinematic-entrance"
              multiline={true}
            />

            {/* CTA Buttons */}
            <div
              className="flex flex-col sm:flex-row gap-4 justify-center mb-16 cinematic-entrance"
              data-animate
              id="hero-cta"
              style={{ animationDelay: "0.6s" }}
            >
              <Dialog open={orderDialog} onOpenChange={setOrderDialog}>
                <DialogTrigger asChild>
                  <Button size="lg" className="btn-gradient px-8 py-4 text-lg font-medium professional-hover">
                    <Send className="h-5 w-5 mr-2" />
                    Mulai Proyek
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="gradient-text-accent">Pesan Layanan Kami</DialogTitle>
                    <DialogDescription>
                      Isi form di bawah ini dan kami akan menghubungi Anda via WhatsApp
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleOrderSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Nama *</Label>
                        <Input
                          id="name"
                          required
                          value={orderForm.name}
                          onChange={(e) => setOrderForm({ ...orderForm, name: e.target.value || "" })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Telepon *</Label>
                        <Input
                          id="phone"
                          required
                          value={orderForm.phone}
                          onChange={(e) => setOrderForm({ ...orderForm, phone: e.target.value || "" })}
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={orderForm.email}
                        onChange={(e) => setOrderForm({ ...orderForm, email: e.target.value || "" })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="service">Layanan *</Label>
                      <select
                        id="service"
                        required
                        value={orderForm.service}
                        onChange={(e) => setOrderForm({ ...orderForm, service: e.target.value || "" })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                      >
                        <option value="">Pilih layanan</option>
                        {content.services.items.map((service) => (
                          <option key={service.id} value={service.title}>
                            {service.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label htmlFor="timeline">Timeline</Label>
                      <Input
                        id="timeline"
                        placeholder="Kapan dibutuhkan?"
                        value={orderForm.timeline}
                        onChange={(e) => setOrderForm({ ...orderForm, timeline: e.target.value || "" })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="description">Deskripsi Kebutuhan *</Label>
                      <Textarea
                        id="description"
                        required
                        rows={3}
                        placeholder="Jelaskan detail kebutuhan Anda..."
                        value={orderForm.description}
                        onChange={(e) => setOrderForm({ ...orderForm, description: e.target.value || "" })}
                      />
                    </div>
                    <Button type="submit" className="w-full btn-gradient">
                      <Send className="h-4 w-4 mr-2" />
                      Kirim via WhatsApp
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>

              <Button
                size="lg"
                variant="outline"
                className="px-8 py-4 text-lg font-medium glass-effect border-white/30 hover:bg-white/20 professional-hover bg-transparent"
                onClick={() => scrollToSection("portfolio")}
              >
                <Play className="h-5 w-5 mr-2" />
                Lihat Portfolio
              </Button>
            </div>

            {/* Stats */}
            <div
              className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto cinematic-entrance"
              data-animate
              id="hero-stats"
              style={{ animationDelay: "0.8s" }}
            >
              {content.hero.stats.map((stat, index) => (
                <div
                  key={index}
                  className="text-center p-4 glass-card rounded-lg professional-hover animate-float"
                  style={{ animationDelay: `${index * 1}s` }}
                >
                  <div className="h-8 w-8 mx-auto mb-2 text-red-500 flex items-center justify-center">
                    {getIcon(stat.icon)}
                  </div>
                  <EditableText
                    value={stat.number}
                    onChange={(value) => updateContent("hero", "stats", value, index, "number")}
                    className="text-2xl font-bold text-gray-900 mb-1 block"
                  />
                  <EditableText
                    value={stat.label}
                    onChange={(value) => updateContent("hero", "stats", value, index, "label")}
                    className="text-sm text-gray-600 block"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* About/Founder Section */}
      <section id="about" className="py-20 relative">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-6xl mx-auto text-center cinematic-entrance" data-animate id="about-content">
            <div className="mb-12">
              <EditableText
                value={content.about.title}
                onChange={(value) => updateContent("about", "title", value)}
                className="text-4xl md:text-5xl font-bold mb-4 gradient-text-section block"
              />
              <EditableText
                value={content.about.subtitle}
                onChange={(value) => updateContent("about", "subtitle", value)}
                className="text-lg text-gray-600 block"
              />
            </div>

            {/* Founders Grid */}
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {content.about.founders.map((founder, index) => (
                <Card
                  key={founder.id}
                  className={`border-0 shadow-2xl glass-card card-gradient-border ${editMode ? "border-2 border-dashed border-blue-300 hover:border-blue-500 transition-colors" : ""}`}
                >
                  <CardContent className="p-8">
                    <div className="flex flex-col items-center gap-6">
                      {/* Profile Photo */}
                      <div className="relative">
                        <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-2xl bg-gradient-to-br from-red-500 to-yellow-500 flex items-center justify-center">
                          {founder.image === "/placeholder.svg?height=400&width=400" ? (
                            <PenTool className="h-16 w-16 text-white" />
                          ) : (
                            <EditableImage
                              src={founder.image}
                              alt={founder.name}
                              onChange={(src) => updateFounder(index, "image", src)}
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>
                        <div className="absolute -inset-1 icon-gradient rounded-full opacity-20 animate-pulse-slow"></div>
                        {editMode && (
                          <div
                            className="absolute inset-0 bg-black bg-opacity-50 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer rounded-full"
                            onClick={() => {
                              const input = document.createElement("input")
                              input.type = "file"
                              input.accept = "image/*"
                              input.onchange = (e) => {
                                const file = (e.target as HTMLInputElement).files?.[0]
                                if (file) {
                                  const reader = new FileReader()
                                  reader.onload = (event) => {
                                    const imageUrl = event.target?.result as string
                                    updateFounder(index, "image", imageUrl)
                                  }
                                  reader.readAsDataURL(file)
                                }
                              }
                              input.click()
                            }}
                          >
                            <div className="bg-white rounded-lg p-2 flex items-center gap-1">
                              <Upload className="h-3 w-3" />
                              <span className="text-xs font-medium">Change</span>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="text-center">
                        <EditableText
                          value={founder.name}
                          onChange={(value) => updateFounder(index, "name", value)}
                          className="text-2xl font-bold text-gray-900 mb-2 block"
                        />
                        <EditableText
                          value={founder.role}
                          onChange={(value) => updateFounder(index, "role", value)}
                          className="text-lg text-red-500 font-medium mb-4 block"
                        />

                        <EditableText
                          value={founder.description}
                          onChange={(value) => updateFounder(index, "description", value)}
                          className="text-gray-600 leading-relaxed mb-6 block text-sm"
                          multiline={true}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Company Stats */}
            <Card
              className={`border-0 shadow-2xl glass-card card-gradient-border ${editMode ? "border-2 border-dashed border-blue-300 hover:border-blue-500 transition-colors" : ""}`}
            >
              <CardContent className="p-8">
                <div className="grid grid-cols-3 gap-6">
                  <div className="text-center">
                    <EditableText
                      value={content.about.companyStats?.experience?.number || "5+"}
                      onChange={(value) => updateCompanyStats("experience", "number", value)}
                      className="text-4xl font-bold text-red-500 mb-1 block"
                    />
                    <EditableText
                      value={content.about.companyStats?.experience?.label || "Tahun Pengalaman"}
                      onChange={(value) => updateCompanyStats("experience", "label", value)}
                      className="text-sm text-gray-600 block"
                    />
                  </div>
                  <div className="text-center">
                    <EditableText
                      value={content.about.companyStats?.projects?.number || "500+"}
                      onChange={(value) => updateCompanyStats("projects", "number", value)}
                      className="text-4xl font-bold text-yellow-500 mb-1 block"
                    />
                    <EditableText
                      value={content.about.companyStats?.projects?.label || "Proyek Selesai"}
                      onChange={(value) => updateCompanyStats("projects", "label", value)}
                      className="text-sm text-gray-600 block"
                    />
                  </div>
                  <div className="text-center">
                    <EditableText
                      value={content.about.companyStats?.clients?.number || "200+"}
                      onChange={(value) => updateCompanyStats("clients", "number", value)}
                      className="text-4xl font-bold text-blue-500 mb-1 block"
                    />
                    <EditableText
                      value={content.about.companyStats?.clients?.label || "Klien Puas"}
                      onChange={(value) => updateCompanyStats("clients", "label", value)}
                      className="text-sm text-gray-600 block"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 relative">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="text-center mb-16 cinematic-entrance" data-animate id="services-header">
            <EditableText
              value={content.services.title}
              onChange={(value) => updateContent("services", "title", value)}
              className="text-4xl md:text-5xl font-bold mb-4 gradient-text-section block"
            />
            <EditableText
              value={content.services.subtitle}
              onChange={(value) => updateContent("services", "subtitle", value)}
              className="text-lg text-gray-600 max-w-2xl mx-auto block"
              multiline={true}
            />
          </div>

          {editMode ? (
            // Edit Mode - Show management interface
            <div className="max-w-6xl mx-auto">
              <div className="mb-8 flex justify-between items-center">
                <h3 className="text-2xl font-bold text-gray-900">Manage Services</h3>
                <Button
                  onClick={() => setShowAddDialog({ type: "service" })}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add New Service
                </Button>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {content.services.items.map((service, index) => (
                  <Card
                    key={service.id}
                    className="border-2 border-dashed border-blue-300 hover:border-blue-500 transition-colors"
                  >
                    <CardHeader className="text-center pb-4">
                      <div className="mx-auto mb-4 p-4 icon-gradient rounded-xl text-white w-fit">
                        {getIcon(service.icon)}
                      </div>
                      <EditableText
                        value={service.title}
                        onChange={(value) => {
                          const newItems = [...content.services.items]
                          newItems[index] = { ...newItems[index], title: value }
                          updateContent("services", "items", newItems)
                        }}
                        className="text-xl text-gray-900 mb-2 block"
                      />
                      <EditableText
                        value={service.description}
                        onChange={(value) => {
                          const newItems = [...content.services.items]
                          newItems[index] = { ...newItems[index], description: value }
                          updateContent("services", "items", newItems)
                        }}
                        className="text-gray-600 block"
                        multiline={true}
                      />
                    </CardHeader>

                    <CardContent className="pt-0">
                      <div className="space-y-2 mb-6">
                        {service.features.map((feature, idx) => (
                          <div key={idx} className="flex items-center text-sm text-gray-600">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                            <EditableText
                              value={feature}
                              onChange={(value) => {
                                const newItems = [...content.services.items]
                                const newFeatures = [...newItems[index].features]
                                newFeatures[idx] = value
                                newItems[index] = { ...newItems[index], features: newFeatures }
                                updateContent("services", "items", newItems)
                              }}
                              className="flex-1"
                            />
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex space-x-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setDuplicateDialog({ type: "service", item: service })}
                          >
                            <Copy className="h-3 w-3 mr-1" />
                            Duplicate
                          </Button>
                        </div>

                        <div className="flex items-center space-x-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => moveItem("service", service.id, "up")}
                            disabled={index === 0}
                          >
                            <ArrowUp className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => moveItem("service", service.id, "down")}
                            disabled={index === content.services.items.length - 1}
                          >
                            <ArrowDown className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 bg-transparent"
                            onClick={() => deleteItem("service", service.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : (
            // Public View
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {content.services.items.map((service, index) => (
                <div
                  key={service.id}
                  className="cinematic-entrance"
                  data-animate
                  id={`service-${index}`}
                  style={{ animationDelay: `${index * 0.15}s` }}
                >
                  <Card className="border-0 shadow-xl glass-card card-gradient-border h-full professional-hover">
                    <CardHeader className="text-center pb-4">
                      <div className="mx-auto mb-4 p-4 icon-gradient rounded-xl text-white w-fit">
                        {getIcon(service.icon)}
                      </div>
                      <CardTitle className="text-xl text-gray-900 mb-2">{service.title}</CardTitle>
                      <CardDescription className="text-gray-600">{service.description}</CardDescription>
                    </CardHeader>

                    <CardContent className="pt-0">
                      <ul className="space-y-2 mb-6">
                        {service.features.map((feature, idx) => (
                          <li key={idx} className="flex items-center text-sm text-gray-600">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 relative">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="text-center mb-16 cinematic-entrance" data-animate id="portfolio-header">
            <EditableText
              value={content.portfolio.title}
              onChange={(value) => updateContent("portfolio", "title", value)}
              className="text-4xl md:text-5xl font-bold mb-4 gradient-text-section block"
            />
            <EditableText
              value={content.portfolio.subtitle}
              onChange={(value) => updateContent("portfolio", "subtitle", value)}
              className="text-lg text-gray-600 max-w-2xl mx-auto block"
              multiline={true}
            />
          </div>

          {editMode ? (
            // Edit Mode - Show management interface
            <div className="max-w-6xl mx-auto">
              <div className="mb-8 flex justify-between items-center">
                <h3 className="text-2xl font-bold text-gray-900">Manage Portfolio</h3>
                <Button
                  onClick={() => setShowAddDialog({ type: "portfolio" })}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add New Portfolio
                </Button>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {content.portfolio.items.map((item, index) => (
                  <Card
                    key={item.id}
                    className="border-2 border-dashed border-blue-300 hover:border-blue-500 transition-colors overflow-hidden"
                  >
                    <div className="aspect-[4/3] bg-gray-200 relative overflow-hidden">
                      <EditableImage
                        src={item.image}
                        alt={item.title}
                        onChange={(src) => {
                          const newItems = [...content.portfolio.items]
                          newItems[index] = { ...newItems[index], image: src }
                          updateContent("portfolio", "items", newItems)
                        }}
                        className="w-full h-full object-cover"
                      />

                      {/* Category Badge */}
                      <div className="absolute top-3 left-3">
                        <EditableText
                          value={item.category}
                          onChange={(value) => {
                            const newItems = [...content.portfolio.items]
                            newItems[index] = { ...newItems[index], category: value }
                            updateContent("portfolio", "items", newItems)
                          }}
                          className="glass-effect text-gray-800 px-3 py-1 rounded-full text-sm font-medium"
                        />
                      </div>
                    </div>

                    <CardContent className="p-6">
                      <EditableText
                        value={item.title}
                        onChange={(value) => {
                          const newItems = [...content.portfolio.items]
                          newItems[index] = { ...newItems[index], title: value }
                          updateContent("portfolio", "items", newItems)
                        }}
                        className="font-bold text-gray-900 text-lg mb-2 block"
                      />
                      <EditableText
                        value={item.client}
                        onChange={(value) => {
                          const newItems = [...content.portfolio.items]
                          newItems[index] = { ...newItems[index], client: value }
                          updateContent("portfolio", "items", newItems)
                        }}
                        className="text-gray-500 text-sm mb-3 block"
                      />
                      <EditableText
                        value={item.description}
                        onChange={(value) => {
                          const newItems = [...content.portfolio.items]
                          newItems[index] = { ...newItems[index], description: value }
                          updateContent("portfolio", "items", newItems)
                        }}
                        className="text-gray-600 text-sm leading-relaxed block"
                        multiline={true}
                      />

                      <div className="flex items-center justify-between mt-4">
                        <div className="flex space-x-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setDuplicateDialog({ type: "portfolio", item })}
                          >
                            <Copy className="h-3 w-3 mr-1" />
                            Duplicate
                          </Button>
                        </div>

                        <div className="flex items-center space-x-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => moveItem("portfolio", item.id, "up")}
                            disabled={index === 0}
                          >
                            <ArrowUp className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => moveItem("portfolio", item.id, "down")}
                            disabled={index === content.portfolio.items.length - 1}
                          >
                            <ArrowDown className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 bg-transparent"
                            onClick={() => deleteItem("portfolio", item.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : (
            // Public View
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {content.portfolio.items.map((item, index) => (
                <div
                  key={item.id}
                  className="cinematic-entrance"
                  data-animate
                  id={`portfolio-${index}`}
                  style={{ animationDelay: `${index * 0.15}s` }}
                >
                  <Card className="border-0 shadow-xl glass-card overflow-hidden professional-hover">
                    <div className="aspect-[4/3] bg-gray-200 relative overflow-hidden">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                      />

                      {/* Category Badge */}
                      <div className="absolute top-3 left-3">
                        <span className="glass-effect text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                          {item.category}
                        </span>
                      </div>

                      {/* Play Button Overlay */}
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300 bg-black/20">
                        <div className="w-16 h-16 icon-gradient rounded-full flex items-center justify-center">
                          <Play className="h-8 w-8 text-white ml-1" />
                        </div>
                      </div>
                    </div>

                    <CardContent className="p-6">
                      <h3 className="font-bold text-gray-900 text-lg mb-2">{item.title}</h3>
                      <p className="text-gray-500 text-sm mb-3">{item.client}</p>
                      <p className="text-gray-600 text-sm leading-relaxed">{item.description}</p>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="text-center mb-16 cinematic-entrance" data-animate id="testimonials-header">
            <EditableText
              value={content.testimonials.title}
              onChange={(value) => updateContent("testimonials", "title", value)}
              className="text-4xl md:text-5xl font-bold mb-4 gradient-text-section block"
            />
            <EditableText
              value={content.testimonials.subtitle}
              onChange={(value) => updateContent("testimonials", "subtitle", value)}
              className="text-lg text-gray-600 max-w-2xl mx-auto block"
              multiline={true}
            />
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {content.testimonials.items.map((testimonial, index) => (
              <div
                key={index}
                className="cinematic-entrance"
                data-animate
                id={`testimonial-${index}`}
                style={{ animationDelay: `${index * 0.15}s` }}
              >
                <Card
                  className={`border-0 shadow-xl glass-card h-full professional-hover ${editMode ? "border-2 border-dashed border-blue-300 hover:border-blue-500" : ""}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <Quote className="h-8 w-8 text-gray-400 mr-3" />
                      <div className="flex">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                        ))}
                      </div>
                    </div>

                    <EditableText
                      value={testimonial.content}
                      onChange={(value) => {
                        const newItems = [...content.testimonials.items]
                        newItems[index] = { ...newItems[index], content: value }
                        updateContent("testimonials", "items", newItems)
                      }}
                      className="text-gray-600 mb-6 italic leading-relaxed block"
                      multiline={true}
                    />

                    <div className="flex items-center">
                      <div className="w-10 h-10 icon-gradient rounded-full flex items-center justify-center mr-3">
                        <User className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <EditableText
                          value={testimonial.name}
                          onChange={(value) => {
                            const newItems = [...content.testimonials.items]
                            newItems[index] = { ...newItems[index], name: value }
                            updateContent("testimonials", "items", newItems)
                          }}
                          className="font-medium text-gray-900 block"
                        />
                        <EditableText
                          value={testimonial.role}
                          onChange={(value) => {
                            const newItems = [...content.testimonials.items]
                            newItems[index] = { ...newItems[index], role: value }
                            updateContent("testimonials", "items", newItems)
                          }}
                          className="text-sm text-gray-500 block"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 relative">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="text-center mb-16 cinematic-entrance" data-animate id="contact-header">
            <EditableText
              value={content.contact.title}
              onChange={(value) => updateContent("contact", "title", value)}
              className="text-4xl md:text-5xl font-bold mb-4 gradient-text-section block"
            />
            <EditableText
              value={content.contact.subtitle}
              onChange={(value) => updateContent("contact", "subtitle", value)}
              className="text-lg text-gray-600 max-w-2xl mx-auto block"
              multiline={true}
            />
          </div>

          <div className="grid lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* Contact Info */}
            <div className="cinematic-entrance" data-animate id="contact-info">
              <div className="space-y-6">
                {content.contact.info.map((contact, index) => (
                  <Card
                    key={index}
                    className={`border-0 shadow-xl glass-card professional-hover ${editMode ? "border-2 border-dashed border-blue-300 hover:border-blue-500" : ""}`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="p-3 icon-gradient rounded-lg">{getIcon(contact.icon)}</div>
                        <div className="flex-1">
                          <EditableText
                            value={contact.title}
                            onChange={(value) => {
                              const newInfo = [...content.contact.info]
                              newInfo[index] = { ...newInfo[index], title: value }
                              updateContent("contact", "info", newInfo)
                            }}
                            className="font-medium text-gray-900 mb-1 block"
                          />
                          <EditableText
                            value={contact.info}
                            onChange={(value) => {
                              const newInfo = [...content.contact.info]
                              newInfo[index] = { ...newInfo[index], info: value }
                              updateContent("contact", "info", newInfo)
                            }}
                            className="text-gray-900 font-medium mb-1 block"
                          />
                          <EditableText
                            value={contact.description}
                            onChange={(value) => {
                              const newInfo = [...content.contact.info]
                              newInfo[index] = { ...newInfo[index], description: value }
                              updateContent("contact", "info", newInfo)
                            }}
                            className="text-gray-600 text-sm block"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Quick WhatsApp */}
              <Card className="btn-gradient text-white border-0 shadow-xl mt-8">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Butuh Respon Cepat?</h3>
                  <p className="mb-4 opacity-90">Hubungi langsung via WhatsApp</p>
                  <Button className="bg-white text-gray-900 hover:bg-gray-100" onClick={() => handleWhatsAppRedirect()}>
                    <Phone className="h-4 w-4 mr-2" />
                    Chat WhatsApp
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <div className="cinematic-entrance" data-animate id="contact-form" style={{ animationDelay: "0.3s" }}>
              <Card className="border-0 shadow-xl glass-card">
                <CardHeader>
                  <CardTitle className="text-2xl text-gray-900 flex items-center">
                    <Send className="h-6 w-6 mr-3 text-red-500" />
                    Kirim Pesan
                  </CardTitle>
                  <CardDescription>
                    Isi form di bawah ini dan kami akan menghubungi Anda dalam 1-2 jam kerja
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleContactSubmit} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="contact-name">Nama Lengkap *</Label>
                        <Input
                          id="contact-name"
                          required
                          value={contactForm.name}
                          onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                          placeholder="Masukkan nama lengkap"
                        />
                      </div>
                      <div>
                        <Label htmlFor="contact-phone">Nomor Telepon *</Label>
                        <Input
                          id="contact-phone"
                          required
                          value={contactForm.phone}
                          onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                          placeholder="+62 812-3456-7890"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="contact-email">Email *</Label>
                      <Input
                        id="contact-email"
                        type="email"
                        required
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        placeholder="nama@email.com"
                      />
                    </div>

                    <div>
                      <Label htmlFor="contact-service">Layanan yang Diminati</Label>
                      <select
                        id="contact-service"
                        value={contactForm.service}
                        onChange={(e) => setContactForm({ ...contactForm, service: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                      >
                        <option value="">Pilih layanan (opsional)</option>
                        {content.services.items.map((service) => (
                          <option key={service.id} value={service.title}>
                            {service.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <Label htmlFor="contact-subject">Subjek *</Label>
                      <Input
                        id="contact-subject"
                        required
                        value={contactForm.subject}
                        onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                        placeholder="Subjek pesan Anda"
                      />
                    </div>

                    <div>
                      <Label htmlFor="contact-message">Pesan *</Label>
                      <Textarea
                        id="contact-message"
                        required
                        rows={4}
                        value={contactForm.message}
                        onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                        placeholder="Ceritakan detail proyek atau pertanyaan Anda..."
                      />
                    </div>

                    <Button type="submit" className="w-full btn-dark">
                      <Send className="h-4 w-4 mr-2" />
                      Kirim Pesan
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-6 lg:px-12 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 gradient-text-section">
              Siap Memulai Proyek Kreatif Anda?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Hubungi kami sekarang dan wujudkan ide kreatif Anda menjadi karya yang memukau
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="btn-gradient px-8 py-3 professional-hover"
                onClick={() => handleWhatsAppRedirect()}
              >
                <Send className="h-5 w-5 mr-2" />
                Hubungi Kami Sekarang
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="glass-effect border-white/30 text-gray-700 hover:bg-white/20 px-8 py-3 professional-hover bg-transparent"
                onClick={() => scrollToSection("portfolio")}
              >
                <Play className="h-5 w-5 mr-2" />
                Lihat Portfolio
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 glass-effect border-t border-white/20">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Sparkles className="h-6 w-6 text-red-500 animate-pulse-slow" />
              <span className="text-lg font-bold gradient-text-accent">Multiplepedia</span>
            </div>
            <p className="text-gray-600 mb-4">
              Creative Multimedia Professional - Menghadirkan solusi kreatif untuk kebutuhan multimedia Anda
            </p>
            <div className="flex justify-center space-x-4 mb-4">
              <a
                href="https://instagram.com/multiplepedia"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 icon-gradient rounded-lg hover:opacity-80 transition-opacity professional-hover"
              >
                <Phone className="h-5 w-5 text-white" />
              </a>
              <a
                href="https://wa.me/62895393181822"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 icon-gradient rounded-lg hover:opacity-80 transition-opacity professional-hover"
              >
                <Phone className="h-5 w-5 text-white" />
              </a>
              <a
                href="mailto:hello@multiplepedia.com"
                className="p-3 icon-gradient rounded-lg hover:opacity-80 transition-opacity professional-hover"
              >
                <Mail className="h-5 w-5 text-white" />
              </a>
            </div>
            <p className="text-gray-500 text-sm">
              © 2024 Multiplepedia. All rights reserved. | Muhammad Fathur Rohman & Fadil Nurrahman Fuadi
            </p>
          </div>
        </div>
      </footer>

      {/* Add Item Dialog */}
      {showAddDialog && (
        <Dialog open={!!showAddDialog} onOpenChange={() => setShowAddDialog(null)}>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New {showAddDialog.type === "service" ? "Service" : "Portfolio Item"}</DialogTitle>
              <DialogDescription>
                {showAddDialog.category && `Adding to category: ${showAddDialog.category}`}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="new-title">Title *</Label>
                <Input
                  id="new-title"
                  value={newItemForm.title}
                  onChange={(e) => setNewItemForm({ ...newItemForm, title: e.target.value })}
                  placeholder="Enter title"
                />
              </div>

              <div>
                <Label htmlFor="new-description">Description *</Label>
                <Textarea
                  id="new-description"
                  value={newItemForm.description}
                  onChange={(e) => setNewItemForm({ ...newItemForm, description: e.target.value })}
                  placeholder="Enter description"
                  rows={3}
                />
              </div>

              {showAddDialog.type === "service" && (
                <>
                  <div>
                    <Label htmlFor="new-icon">Icon</Label>
                    <select
                      id="new-icon"
                      value={newItemForm.icon}
                      onChange={(e) => setNewItemForm({ ...newItemForm, icon: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                      <option value="Video">Video</option>
                      <option value="Camera">Camera</option>
                      <option value="Edit">Edit</option>
                      <option value="Palette">Palette</option>
                      <option value="Radio">Radio</option>
                      <option value="Share2">Share2</option>
                      <option value="Sparkles">Sparkles</option>
                      <option value="PenTool">PenTool</option>
                    </select>
                  </div>

                  <div>
                    <Label>Features</Label>
                    {newItemForm.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2 mt-2">
                        <Input
                          value={feature}
                          onChange={(e) => updateFeature(index, e.target.value)}
                          placeholder={`Feature ${index + 1}`}
                        />
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => removeFeature(index)}
                          disabled={newItemForm.features.length <= 1}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={addFeature}
                      className="mt-2 bg-transparent"
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Add Feature
                    </Button>
                  </div>
                </>
              )}

              {showAddDialog.type === "portfolio" && (
                <>
                  <div>
                    <Label htmlFor="new-category">Category</Label>
                    <select
                      id="new-category"
                      onChange={(e) => {
                        const category = e.target.value
                        window.location.href = "https://wa.me/62895393181822"
                      }}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                      <option value="">Pilih kategori</option>
                      <option value="Videography">Videography</option>
                      <option value="Photography">Photography</option>
                      <option value="Design">Design</option>
                      <option value="Video Editing">Video Editing</option>
                      <option value="Live Streaming">Live Streaming</option>
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="new-client">Client</Label>
                    <Input
                      id="new-client"
                      value={newItemForm.client}
                      onChange={(e) => setNewItemForm({ ...newItemForm, client: e.target.value })}
                      placeholder="Client name"
                    />
                  </div>

                  <div>
                    <Label>Image</Label>
                    <div className="flex items-center space-x-2">
                      <img
                        src={newItemForm.image || "/placeholder.svg"}
                        alt="Preview"
                        className="w-20 h-20 object-cover rounded border"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          const input = document.createElement("input")
                          input.type = "file"
                          input.accept = "image/*"
                          input.onchange = (e) => {
                            const file = (e.target as HTMLInputElement).files?.[0]
                            if (file) {
                              const reader = new FileReader()
                              reader.onload = (event) => {
                                const imageUrl = event.target?.result as string
                                setNewItemForm({ ...newItemForm, image: imageUrl })
                              }
                              reader.readAsDataURL(file)
                            }
                          }
                          input.click()
                        }}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Image
                      </Button>
                    </div>
                  </div>
                </>
              )}

              <div className="flex space-x-2 pt-4">
                <Button
                  onClick={() => addNewItem(showAddDialog.type as "service" | "portfolio")}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  disabled={!newItemForm.title || !newItemForm.description}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create {showAddDialog.type === "service" ? "Service" : "Portfolio Item"}
                </Button>
                <Button variant="outline" onClick={() => setShowAddDialog(null)} className="flex-1">
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Duplicate Item Dialog */}
      {duplicateDialog && (
        <Dialog open={!!duplicateDialog} onOpenChange={() => setDuplicateDialog(null)}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Duplicate {duplicateDialog.type === "service" ? "Service" : "Portfolio Item"}</DialogTitle>
              <DialogDescription>This will create a copy of "{duplicateDialog.item.title}"</DialogDescription>
            </DialogHeader>
            <div className="flex space-x-2">
              <Button
                onClick={() => duplicateItem(duplicateDialog.type as "service" | "portfolio", duplicateDialog.item)}
                className="flex-1"
              >
                <Copy className="h-4 w-4 mr-2" />
                Duplicate
              </Button>
              <Button variant="outline" onClick={() => setDuplicateDialog(null)} className="flex-1">
                Cancel
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
