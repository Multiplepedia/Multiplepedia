"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  Settings,
  Plus,
  Edit,
  Trash2,
  Eye,
  Mail,
  Save,
  Sparkles,
  Camera,
  Video,
  Palette,
  Monitor,
  BarChart3,
  TrendingUp,
  CheckCircle,
  Clock,
  XCircle,
  Star,
  Award,
  Target,
} from "lucide-react"

export default function AdminDashboard() {
  const [animatedCards, setAnimatedCards] = useState<Set<number>>(new Set())
  const [orders, setOrders] = useState([
    {
      id: 1,
      name: "John Doe",
      email: "john@example.com",
      phone: "081234567890",
      service: "videografi",
      description: "Wedding video untuk acara pernikahan",
      budget: "Rp 10.000.000",
      status: "pending",
      date: "2024-01-15",
      priority: "high",
    },
    {
      id: 2,
      name: "Jane Smith",
      email: "jane@example.com",
      phone: "081234567891",
      service: "fotografi",
      description: "Product photography untuk e-commerce",
      budget: "Rp 5.000.000",
      status: "approved",
      date: "2024-01-14",
      priority: "medium",
    },
    {
      id: 3,
      name: "Mike Johnson",
      email: "mike@example.com",
      phone: "081234567892",
      service: "design",
      description: "Logo design untuk startup baru",
      budget: "Rp 3.000.000",
      status: "completed",
      date: "2024-01-13",
      priority: "low",
    },
  ])

  const [portfolioItems, setPortfolioItems] = useState([
    {
      id: 1,
      title: "Wedding Video - Sarah & John",
      category: "videografi",
      description: "Cinematic wedding video with drone shots",
      image: "/placeholder.svg?height=200&width=300",
      status: "published",
      views: 1250,
      likes: 89,
    },
    {
      id: 2,
      title: "Product Photography - Fashion Brand",
      category: "fotografi",
      description: "Commercial product photography for e-commerce",
      image: "/placeholder.svg?height=200&width=300",
      status: "published",
      views: 890,
      likes: 67,
    },
    {
      id: 3,
      title: "Corporate Video - Tech Company",
      category: "videografi",
      description: "Professional corporate video presentation",
      image: "/placeholder.svg?height=200&width=300",
      status: "draft",
      views: 0,
      likes: 0,
    },
  ])

  const [siteSettings, setSiteSettings] = useState({
    siteName: "Visual Creative Project",
    tagline: "Creative Multimedia Professional",
    description: "Spesialis dalam videografi, fotografi, editing video, dan desain grafis",
    contactEmail: "admin@visualcreativeproject.com",
    phone: "+62 812-3456-7890",
    address: "Jakarta, Indonesia",
    socialMedia: {
      instagram: "@visualcreativeproject",
      linkedin: "visual-creative-project",
      behance: "visualcreativeproject",
      youtube: "VisualCreativeProject",
    },
  })

  // Animate cards on mount
  useEffect(() => {
    const timer = setInterval(() => {
      setAnimatedCards((prev) => {
        const newSet = new Set(prev)
        newSet.add(prev.size)
        return newSet
      })
    }, 200)

    setTimeout(() => clearInterval(timer), 1000)
    return () => clearInterval(timer)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "approved":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "completed":
        return "bg-green-100 text-green-800 border-green-200"
      case "rejected":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const updateOrderStatus = (orderId: number, newStatus: string) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order)))
  }

  const deleteOrder = (orderId: number) => {
    setOrders(orders.filter((order) => order.id !== orderId))
  }

  const deletePortfolioItem = (itemId: number) => {
    setPortfolioItems(portfolioItems.filter((item) => item.id !== itemId))
  }

  const addNewPortfolioItem = () => {
    const newItem = {
      id: Date.now(),
      title: "New Portfolio Item",
      category: "design",
      description: "Description for new portfolio item",
      image: "/placeholder.svg?height=200&width=300",
      status: "draft",
      views: 0,
      likes: 0,
    }
    setPortfolioItems([...portfolioItems, newItem])
  }

  const stats = {
    totalOrders: orders.length,
    pendingOrders: orders.filter((o) => o.status === "pending").length,
    completedOrders: orders.filter((o) => o.status === "completed").length,
    totalPortfolio: portfolioItems.length,
    totalViews: portfolioItems.reduce((sum, item) => sum + item.views, 0),
    totalLikes: portfolioItems.reduce((sum, item) => sum + item.likes, 0),
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center shadow-lg">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
                  Admin Dashboard
                </h1>
                <p className="text-sm text-gray-600">Visual Creative Project</p>
              </div>
            </div>
            <Button
              variant="outline"
              className="bg-white text-gray-700 border-gray-300 hover:bg-red-50 hover:border-red-300 transition-all duration-300"
            >
              <Eye className="h-4 w-4 mr-2" />
              View Site
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Enhanced Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            {
              title: "Total Orders",
              value: stats.totalOrders,
              icon: Users,
              color: "blue",
              trend: "+12%",
              description: "dari bulan lalu",
            },
            {
              title: "Pending Orders",
              value: stats.pendingOrders,
              icon: Clock,
              color: "yellow",
              trend: "+5%",
              description: "perlu ditindaklanjuti",
            },
            {
              title: "Completed",
              value: stats.completedOrders,
              icon: CheckCircle,
              color: "green",
              trend: "+18%",
              description: "proyek selesai",
            },
            {
              title: "Portfolio Items",
              value: stats.totalPortfolio,
              icon: Award,
              color: "purple",
              trend: "+8%",
              description: "karya dipublikasi",
            },
          ].map((stat, index) => (
            <Card
              key={index}
              className={`border-gray-200 shadow-lg hover:shadow-xl transition-all duration-500 transform hover:scale-105 ${
                animatedCards.has(index) ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 bg-${stat.color}-100 rounded-full`}>
                    <stat.icon className={`h-6 w-6 text-${stat.color}-600`} />
                  </div>
                  <Badge
                    variant="outline"
                    className={`bg-${stat.color}-50 text-${stat.color}-700 border-${stat.color}-200`}
                  >
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {stat.trend}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</p>
                  <p className="text-xs text-gray-500">{stat.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Stats Row */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-gray-200 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Views</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalViews.toLocaleString()}</p>
                  <p className="text-xs text-gray-500">portfolio views</p>
                </div>
                <div className="p-3 bg-indigo-100 rounded-full">
                  <BarChart3 className="h-6 w-6 text-indigo-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-gray-200 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Likes</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalLikes}</p>
                  <p className="text-xs text-gray-500">engagement rate</p>
                </div>
                <div className="p-3 bg-pink-100 rounded-full">
                  <Star className="h-6 w-6 text-pink-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="orders" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8 bg-white shadow-lg">
            <TabsTrigger
              value="orders"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-500 data-[state=active]:text-white transition-all duration-300"
            >
              Orders
            </TabsTrigger>
            <TabsTrigger
              value="portfolio"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-blue-500 data-[state=active]:text-white transition-all duration-300"
            >
              Portfolio
            </TabsTrigger>
            <TabsTrigger
              value="analytics"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-600 data-[state=active]:to-green-500 data-[state=active]:text-white transition-all duration-300"
            >
              Analytics
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-purple-500 data-[state=active]:text-white transition-all duration-300"
            >
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="mt-6">
            <Card className="shadow-xl">
              <CardHeader className="bg-gradient-to-r from-red-50 to-yellow-50">
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-red-600" />
                  Customer Orders
                </CardTitle>
                <CardDescription>Kelola pesanan dari pelanggan dengan sistem prioritas</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {orders.map((order, index) => (
                    <Card
                      key={order.id}
                      className="border border-gray-200 hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02]"
                    >
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center space-x-3">
                            <div className={`w-3 h-3 rounded-full ${getPriorityColor(order.priority)}`}></div>
                            <div>
                              <h3 className="font-semibold text-gray-900">{order.name}</h3>
                              <p className="text-sm text-gray-600">{order.email}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={getStatusColor(order.status)}>
                              {order.status === "pending" && <Clock className="h-3 w-3 mr-1" />}
                              {order.status === "approved" && <CheckCircle className="h-3 w-3 mr-1" />}
                              {order.status === "completed" && <Award className="h-3 w-3 mr-1" />}
                              {order.status === "rejected" && <XCircle className="h-3 w-3 mr-1" />}
                              {order.status}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {order.priority} priority
                            </Badge>
                          </div>
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                          <div>
                            <p className="text-sm text-gray-600">Service:</p>
                            <div className="flex items-center">
                              {order.service === "videografi" && <Video className="h-4 w-4 mr-1 text-red-600" />}
                              {order.service === "fotografi" && <Camera className="h-4 w-4 mr-1 text-blue-600" />}
                              {order.service === "design" && <Palette className="h-4 w-4 mr-1 text-green-600" />}
                              {order.service === "editing" && <Monitor className="h-4 w-4 mr-1 text-purple-600" />}
                              <p className="font-medium capitalize">{order.service}</p>
                            </div>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Budget:</p>
                            <p className="font-medium text-green-600">{order.budget}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Date:</p>
                            <p className="font-medium">{order.date}</p>
                          </div>
                        </div>

                        <div className="mb-4">
                          <p className="text-sm text-gray-600 mb-1">Description:</p>
                          <p className="text-sm bg-gray-50 p-2 rounded">{order.description}</p>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700 transition-colors duration-300"
                              onClick={() => updateOrderStatus(order.id, "approved")}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              className="bg-blue-600 hover:bg-blue-700 transition-colors duration-300"
                              onClick={() => updateOrderStatus(order.id, "completed")}
                            >
                              <Award className="h-4 w-4 mr-1" />
                              Complete
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => updateOrderStatus(order.id, "rejected")}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline">
                              <Mail className="h-4 w-4 mr-1" />
                              Contact
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 hover:text-red-700"
                              onClick={() => deleteOrder(order.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="portfolio" className="mt-6">
            <Card className="shadow-xl">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-green-50">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center">
                      <Eye className="h-5 w-5 mr-2 text-blue-600" />
                      Portfolio Management
                    </CardTitle>
                    <CardDescription>Kelola karya portfolio dengan analytics</CardDescription>
                  </div>
                  <Button
                    onClick={addNewPortfolioItem}
                    className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 transition-all duration-300"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Portfolio
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {portfolioItems.map((item, index) => (
                    <Card
                      key={item.id}
                      className="overflow-hidden border border-gray-200 hover:shadow-xl transition-all duration-500 transform hover:scale-105 group"
                    >
                      <div className="aspect-video bg-gray-200 relative overflow-hidden">
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        <Badge
                          className={`absolute top-2 right-2 ${
                            item.status === "published" ? "bg-green-600 text-white" : "bg-yellow-600 text-white"
                          }`}
                        >
                          {item.status}
                        </Badge>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors duration-300">
                          {item.title}
                        </h3>
                        <Badge variant="outline" className="mb-2 capitalize">
                          {item.category === "videografi" && <Video className="h-3 w-3 mr-1" />}
                          {item.category === "fotografi" && <Camera className="h-3 w-3 mr-1" />}
                          {item.category === "design" && <Palette className="h-3 w-3 mr-1" />}
                          {item.category}
                        </Badge>
                        <p className="text-sm text-gray-600 mb-4">{item.description}</p>

                        <div className="flex justify-between items-center mb-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Eye className="h-4 w-4 mr-1" />
                            {item.views}
                          </div>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 mr-1" />
                            {item.likes}
                          </div>
                        </div>

                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" className="flex-1">
                            <Edit className="h-4 w-4 mr-1" />
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600 hover:text-red-700"
                            onClick={() => deletePortfolioItem(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="shadow-xl">
                <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50">
                  <CardTitle className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2 text-green-600" />
                    Performance Analytics
                  </CardTitle>
                  <CardDescription>Statistik performa website dan portfolio</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm font-medium">Total Page Views</span>
                      <span className="text-lg font-bold text-blue-600">15,234</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm font-medium">Unique Visitors</span>
                      <span className="text-lg font-bold text-green-600">8,456</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm font-medium">Bounce Rate</span>
                      <span className="text-lg font-bold text-yellow-600">23.5%</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm font-medium">Avg. Session Duration</span>
                      <span className="text-lg font-bold text-purple-600">4:32</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-xl">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <CardTitle className="flex items-center">
                    <Target className="h-5 w-5 mr-2 text-purple-600" />
                    Service Analytics
                  </CardTitle>
                  <CardDescription>Analisis permintaan layanan</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {[
                      { service: "Videografi", requests: 45, color: "red" },
                      { service: "Fotografi", requests: 32, color: "blue" },
                      { service: "Video Editing", requests: 28, color: "green" },
                      { service: "Graphic Design", requests: 19, color: "purple" },
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{item.service}</span>
                          <span className="text-sm font-bold">{item.requests} requests</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`bg-${item.color}-500 h-2 rounded-full transition-all duration-1000`}
                            style={{ width: `${(item.requests / 45) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="shadow-xl">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                  <CardTitle className="flex items-center">
                    <Settings className="h-5 w-5 mr-2 text-purple-600" />
                    Site Settings
                  </CardTitle>
                  <CardDescription>Konfigurasi website Visual Creative Project</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-6">
                  <div className="space-y-2">
                    <Label htmlFor="site-name">Site Name</Label>
                    <Input
                      id="site-name"
                      value={siteSettings.siteName}
                      onChange={(e) => setSiteSettings({ ...siteSettings, siteName: e.target.value })}
                      className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tagline">Tagline</Label>
                    <Input
                      id="tagline"
                      value={siteSettings.tagline}
                      onChange={(e) => setSiteSettings({ ...siteSettings, tagline: e.target.value })}
                      className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      rows={3}
                      value={siteSettings.description}
                      onChange={(e) => setSiteSettings({ ...siteSettings, description: e.target.value })}
                      className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                    />
                  </div>
                  <Button className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 transition-all duration-300">
                    <Save className="h-4 w-4 mr-2" />
                    Save Site Settings
                  </Button>
                </CardContent>
              </Card>

              <Card className="shadow-xl">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-green-50">
                  <CardTitle className="flex items-center">
                    <Mail className="h-5 w-5 mr-2 text-blue-600" />
                    Contact Information
                  </CardTitle>
                  <CardDescription>Update informasi kontak dan media sosial</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-6">
                  <div className="space-y-2">
                    <Label htmlFor="contact-email">Email</Label>
                    <Input
                      id="contact-email"
                      type="email"
                      value={siteSettings.contactEmail}
                      onChange={(e) => setSiteSettings({ ...siteSettings, contactEmail: e.target.value })}
                      className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={siteSettings.phone}
                      onChange={(e) => setSiteSettings({ ...siteSettings, phone: e.target.value })}
                      className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      value={siteSettings.address}
                      onChange={(e) => setSiteSettings({ ...siteSettings, address: e.target.value })}
                      className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Social Media</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="Instagram"
                        value={siteSettings.socialMedia.instagram}
                        onChange={(e) =>
                          setSiteSettings({
                            ...siteSettings,
                            socialMedia: { ...siteSettings.socialMedia, instagram: e.target.value },
                          })
                        }
                        className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      />
                      <Input
                        placeholder="LinkedIn"
                        value={siteSettings.socialMedia.linkedin}
                        onChange={(e) =>
                          setSiteSettings({
                            ...siteSettings,
                            socialMedia: { ...siteSettings.socialMedia, linkedin: e.target.value },
                          })
                        }
                        className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      />
                      <Input
                        placeholder="Behance"
                        value={siteSettings.socialMedia.behance}
                        onChange={(e) =>
                          setSiteSettings({
                            ...siteSettings,
                            socialMedia: { ...siteSettings.socialMedia, behance: e.target.value },
                          })
                        }
                        className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      />
                      <Input
                        placeholder="YouTube"
                        value={siteSettings.socialMedia.youtube}
                        onChange={(e) =>
                          setSiteSettings({
                            ...siteSettings,
                            socialMedia: { ...siteSettings.socialMedia, youtube: e.target.value },
                          })
                        }
                        className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 transition-all duration-300">
                    <Save className="h-4 w-4 mr-2" />
                    Save Contact Info
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
