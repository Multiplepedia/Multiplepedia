"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, MessageCircle, Trash2, Reply, Search, Phone, User, Calendar, Tag } from "lucide-react"

interface Message {
  id: number
  name: string
  email: string
  phone: string
  subject: string
  message: string
  service: string
  date: string
  status: "unread" | "read" | "replied"
  priority: "low" | "medium" | "high"
}

export default function AdminInbox() {
  const [messages, setMessages] = useState<Message[]>([])
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null)
  const [filterStatus, setFilterStatus] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [replyText, setReplyText] = useState("")

  // Load messages from localStorage
  useEffect(() => {
    const loadMessages = () => {
      const storedMessages = JSON.parse(localStorage.getItem("adminMessages") || "[]")
      // Add priority and ensure all required fields
      const messagesWithPriority = storedMessages.map((msg: any) => ({
        ...msg,
        priority: msg.priority || "medium",
        status: msg.status || "unread",
      }))
      setMessages(messagesWithPriority)
    }

    loadMessages()

    // Refresh every 30 seconds to check for new messages
    const interval = setInterval(loadMessages, 30000)
    return () => clearInterval(interval)
  }, [])

  const filteredMessages = messages.filter((message) => {
    const matchesStatus = filterStatus === "all" || message.status === filterStatus
    const matchesSearch =
      searchTerm === "" ||
      message.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.subject.toLowerCase().includes(searchTerm.toLowerCase())

    return matchesStatus && matchesSearch
  })

  const markAsRead = (messageId: number) => {
    const updatedMessages = messages.map((msg) => (msg.id === messageId ? { ...msg, status: "read" as const } : msg))
    setMessages(updatedMessages)
    localStorage.setItem("adminMessages", JSON.stringify(updatedMessages))
  }

  const markAsReplied = (messageId: number) => {
    const updatedMessages = messages.map((msg) => (msg.id === messageId ? { ...msg, status: "replied" as const } : msg))
    setMessages(updatedMessages)
    localStorage.setItem("adminMessages", JSON.stringify(updatedMessages))
  }

  const deleteMessage = (messageId: number) => {
    if (confirm("Apakah Anda yakin ingin menghapus pesan ini?")) {
      const updatedMessages = messages.filter((msg) => msg.id !== messageId)
      setMessages(updatedMessages)
      localStorage.setItem("adminMessages", JSON.stringify(updatedMessages))
      setSelectedMessage(null)
    }
  }

  const handleReply = (message: Message) => {
    const whatsappMessage = `Halo ${message.name},

Terima kasih telah menghubungi Visual Creative Project.

${replyText}

Salam,
Tim Visual Creative Project`

    const whatsappUrl = `https://wa.me/${message.phone.replace(/\D/g, "")}?text=${encodeURIComponent(whatsappMessage)}`
    window.open(whatsappUrl, "_blank")

    markAsReplied(message.id)
    setReplyText("")
    alert("Reply berhasil dikirim via WhatsApp!")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "unread":
        return "bg-red-100 text-red-800 border-red-200"
      case "read":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "replied":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const stats = {
    total: messages.length,
    unread: messages.filter((m) => m.status === "unread").length,
    read: messages.filter((m) => m.status === "read").length,
    replied: messages.filter((m) => m.status === "replied").length,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Mail className="h-8 w-8 mr-3 text-red-600" />
                Admin Inbox
              </h1>
              <p className="text-gray-600 mt-1">Kelola pesan dari pelanggan</p>
            </div>

            {/* Stats */}
            <div className="flex space-x-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
                <div className="text-sm text-gray-600">Total</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{stats.unread}</div>
                <div className="text-sm text-gray-600">Unread</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.replied}</div>
                <div className="text-sm text-gray-600">Replied</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Messages List */}
          <div className="lg:col-span-1">
            <Card className="shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <MessageCircle className="h-5 w-5 mr-2 text-blue-600" />
                    Messages ({filteredMessages.length})
                  </CardTitle>
                </div>

                {/* Search and Filter */}
                <div className="space-y-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search messages..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="all">All Messages</option>
                    <option value="unread">Unread</option>
                    <option value="read">Read</option>
                    <option value="replied">Replied</option>
                  </select>
                </div>
              </CardHeader>

              <CardContent className="p-0">
                <div className="max-h-96 overflow-y-auto">
                  {filteredMessages.length === 0 ? (
                    <div className="p-6 text-center text-gray-500">
                      <Mail className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                      <p>No messages found</p>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {filteredMessages.map((message) => (
                        <div
                          key={message.id}
                          onClick={() => {
                            setSelectedMessage(message)
                            if (message.status === "unread") {
                              markAsRead(message.id)
                            }
                          }}
                          className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors duration-200 ${
                            selectedMessage?.id === message.id ? "bg-blue-50 border-l-4 border-l-blue-500" : ""
                          } ${message.status === "unread" ? "bg-red-50" : ""}`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              <div className={`w-3 h-3 rounded-full ${getPriorityColor(message.priority)}`}></div>
                              <h4 className={`font-medium text-sm ${message.status === "unread" ? "font-bold" : ""}`}>
                                {message.name}
                              </h4>
                            </div>
                            <Badge className={`text-xs ${getStatusColor(message.status)}`}>{message.status}</Badge>
                          </div>

                          <p className="text-sm text-gray-900 font-medium mb-1 truncate">{message.subject}</p>

                          <p className="text-xs text-gray-600 mb-2 line-clamp-2">{message.message}</p>

                          <div className="flex items-center justify-between text-xs text-gray-500">
                            <span>{new Date(message.date).toLocaleDateString("id-ID")}</span>
                            {message.service && (
                              <Badge variant="outline" className="text-xs">
                                {message.service}
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Message Detail */}
          <div className="lg:col-span-2">
            {selectedMessage ? (
              <Card className="shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-4 h-4 rounded-full ${getPriorityColor(selectedMessage.priority)}`}></div>
                      <div>
                        <CardTitle className="text-xl">{selectedMessage.subject}</CardTitle>
                        <CardDescription className="flex items-center space-x-4 mt-1">
                          <span className="flex items-center">
                            <User className="h-4 w-4 mr-1" />
                            {selectedMessage.name}
                          </span>
                          <span className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1" />
                            {new Date(selectedMessage.date).toLocaleDateString("id-ID")}
                          </span>
                        </CardDescription>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(selectedMessage.status)}>{selectedMessage.status}</Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => deleteMessage(selectedMessage.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  {/* Contact Info */}
                  <div className="grid md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-xs text-gray-500">Email</p>
                        <p className="text-sm font-medium">{selectedMessage.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-xs text-gray-500">Phone</p>
                        <p className="text-sm font-medium">{selectedMessage.phone}</p>
                      </div>
                    </div>
                    {selectedMessage.service && (
                      <div className="flex items-center space-x-2">
                        <Tag className="h-4 w-4 text-gray-500" />
                        <div>
                          <p className="text-xs text-gray-500">Service</p>
                          <p className="text-sm font-medium">{selectedMessage.service}</p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Message Content */}
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Message:</h4>
                    <div className="p-4 bg-white border border-gray-200 rounded-lg">
                      <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{selectedMessage.message}</p>
                    </div>
                  </div>

                  {/* Reply Section */}
                  <div className="border-t pt-6">
                    <h4 className="font-medium text-gray-900 mb-3 flex items-center">
                      <Reply className="h-4 w-4 mr-2" />
                      Quick Reply via WhatsApp:
                    </h4>
                    <Textarea
                      placeholder="Type your reply here..."
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      rows={4}
                      className="mb-4"
                    />
                    <div className="flex space-x-3">
                      <Button
                        onClick={() => handleReply(selectedMessage)}
                        className="bg-green-600 hover:bg-green-700"
                        disabled={!replyText.trim()}
                      >
                        <Reply className="h-4 w-4 mr-2" />
                        Send via WhatsApp
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => window.open(`mailto:${selectedMessage.email}`, "_blank")}
                      >
                        <Mail className="h-4 w-4 mr-2" />
                        Reply via Email
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="shadow-lg">
                <CardContent className="p-12 text-center">
                  <Mail className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-xl font-medium text-gray-900 mb-2">Select a Message</h3>
                  <p className="text-gray-600">Choose a message from the list to view details and reply</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
