"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Lock, User, Menu, X, LogOut } from "lucide-react"

export default function Header() {
  const [isLoginOpen, setIsLoginOpen] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userType, setUserType] = useState<"admin" | "customer" | null>(null)
  const [activeSection, setActiveSection] = useState("hero")
  const pathname = usePathname() || "/"

  // Navigation for single page (customers) vs separate pages (admin)
  const customerNavigation = [
    { name: "Home", href: "#hero" },
    { name: "About", href: "#about" },
    { name: "Services", href: "#services" },
    { name: "Portfolio", href: "#portfolio" },
    { name: "Contact", href: "#contact" },
  ]

  const adminNavigation = [
    { name: "Home", href: "/" },
    { name: "Admin Dashboard", href: "/admin" },
    { name: "Inbox", href: "/admin/inbox" },
  ]

  // Check login status
  useEffect(() => {
    try {
      const adminStatus = localStorage.getItem("isAdmin")
      const customerStatus = localStorage.getItem("isCustomer")

      if (adminStatus === "true") {
        setIsLoggedIn(true)
        setUserType("admin")
      } else if (customerStatus === "true") {
        setIsLoggedIn(true)
        setUserType("customer")
      }
    } catch (error) {
      console.error("Error checking login status:", error)
    }
  }, [])

  // Track active section for customers on homepage
  useEffect(() => {
    if (pathname === "/" && userType !== "admin") {
      const handleScroll = () => {
        const sections = ["hero", "about", "services", "portfolio", "contact"]
        const scrollPosition = window.scrollY + 100

        for (const section of sections) {
          const element = document.getElementById(section)
          if (element) {
            const offsetTop = element.offsetTop
            const offsetHeight = element.offsetHeight

            if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
              setActiveSection(section)
              break
            }
          }
        }
      }

      window.addEventListener("scroll", handleScroll)
      return () => window.removeEventListener("scroll", handleScroll)
    }
  }, [pathname, userType])

  const handleLogin = (type: "admin" | "customer", formData: FormData) => {
    try {
      const email = formData.get("email") as string
      const password = formData.get("password") as string

      if (type === "admin" && email && password) {
        localStorage.setItem("isAdmin", "true")
        localStorage.setItem("adminEmail", email)
        setIsLoggedIn(true)
        setUserType("admin")
        setIsLoginOpen(false)
        alert("Login admin berhasil!")
        window.location.reload()
      } else if (type === "customer" && email && password) {
        localStorage.setItem("isCustomer", "true")
        localStorage.setItem("customerEmail", email)
        setIsLoggedIn(true)
        setUserType("customer")
        setIsLoginOpen(false)
        alert("Login customer berhasil!")
      } else {
        alert("Please fill in all fields")
      }
    } catch (error) {
      console.error("Error during login:", error)
      alert("Login error occurred")
    }
  }

  const handleLogout = () => {
    try {
      localStorage.removeItem("isAdmin")
      localStorage.removeItem("isCustomer")
      localStorage.removeItem("adminEmail")
      localStorage.removeItem("customerEmail")
      setIsLoggedIn(false)
      setUserType(null)
      alert("Logout berhasil!")
      window.location.reload()
    } catch (error) {
      console.error("Error during logout:", error)
    }
  }

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId.replace("#", ""))
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" })
    }
    setIsMenuOpen(false)
  }

  const navigation = userType === "admin" ? adminNavigation : customerNavigation
  const isHomePage = pathname === "/"

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-white/20 shadow-lg transition-all duration-300">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo - Text Only */}
          <Link href="/" className="group">
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold gradient-text-main mb-1">Multiplepedia</div>
              <div className="text-xs text-gray-600 -mt-1">Creative Multimedia Professional</div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-1">
            {navigation.map((item) => {
              const isActive =
                isHomePage && userType !== "admin"
                  ? activeSection === item.href.replace("#", "")
                  : pathname === item.href

              return (
                <button
                  key={item.name}
                  onClick={() => {
                    if (item.href.startsWith("#")) {
                      scrollToSection(item.href)
                    } else {
                      window.location.href = item.href
                    }
                  }}
                  className={`relative px-4 py-2 text-sm font-medium rounded-lg transition-all duration-300 group ${
                    isActive ? "text-gray-900 bg-white/10" : "text-gray-700 hover:text-gray-900 hover:bg-white/10"
                  }`}
                >
                  {item.name}
                  {isActive && (
                    <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-red-600 rounded-full"></span>
                  )}
                </button>
              )
            })}
          </nav>

          {/* Auth & Mobile Menu */}
          <div className="flex items-center space-x-3">
            {isLoggedIn ? (
              <div className="flex items-center space-x-3">
                <div className="hidden sm:flex items-center space-x-2">
                  <div className="w-8 h-8 icon-gradient rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-sm text-gray-700">{userType === "admin" ? "Admin" : "Customer"}</span>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleLogout}
                  className="glass-effect text-gray-700 border-white/30 hover:bg-white/20 transition-all duration-300 bg-transparent"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Logout</span>
                </Button>
              </div>
            ) : (
              <Dialog open={isLoginOpen} onOpenChange={setIsLoginOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="btn-gradient">
                    <Lock className="h-4 w-4 mr-2" />
                    Login
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-center text-xl font-bold gradient-text-accent">
                      Login to Visual Creative Project
                    </DialogTitle>
                    <DialogDescription className="text-center">Choose your account type to continue</DialogDescription>
                  </DialogHeader>

                  <Tabs defaultValue="customer" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger
                        value="customer"
                        className="data-[state=active]:btn-gradient data-[state=active]:text-white"
                      >
                        <User className="h-4 w-4 mr-2" />
                        Customer
                      </TabsTrigger>
                      <TabsTrigger
                        value="admin"
                        className="data-[state=active]:btn-gradient data-[state=active]:text-white"
                      >
                        <Lock className="h-4 w-4 mr-2" />
                        Admin
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="customer">
                      <form
                        onSubmit={(e) => {
                          e.preventDefault()
                          const formData = new FormData(e.currentTarget)
                          handleLogin("customer", formData)
                        }}
                        className="space-y-4"
                      >
                        <div className="space-y-2">
                          <Label htmlFor="customer-email">Email</Label>
                          <Input
                            id="customer-email"
                            name="email"
                            type="email"
                            required
                            placeholder="customer@example.com"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="customer-password">Password</Label>
                          <Input
                            id="customer-password"
                            name="password"
                            type="password"
                            required
                            placeholder="Enter your password"
                          />
                        </div>
                        <Button type="submit" className="w-full btn-gradient">
                          <User className="h-4 w-4 mr-2" />
                          Login as Customer
                        </Button>
                        <p className="text-xs text-gray-500 text-center">
                          Don't have an account? Contact us to register.
                        </p>
                      </form>
                    </TabsContent>

                    <TabsContent value="admin">
                      <form
                        onSubmit={(e) => {
                          e.preventDefault()
                          const formData = new FormData(e.currentTarget)
                          handleLogin("admin", formData)
                        }}
                        className="space-y-4"
                      >
                        <div className="space-y-2">
                          <Label htmlFor="admin-email">Admin Email</Label>
                          <Input
                            id="admin-email"
                            name="email"
                            type="email"
                            required
                            placeholder="admin@visualcreativeproject.com"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="admin-password">Admin Password</Label>
                          <Input
                            id="admin-password"
                            name="password"
                            type="password"
                            required
                            placeholder="Enter admin password"
                          />
                        </div>
                        <Button type="submit" className="w-full btn-gradient">
                          <Lock className="h-4 w-4 mr-2" />
                          Login as Admin
                        </Button>
                      </form>
                    </TabsContent>
                  </Tabs>
                </DialogContent>
              </Dialog>
            )}

            {/* Mobile Menu Button */}
            <Button
              size="sm"
              variant="outline"
              className="md:hidden glass-effect border-white/30 hover:bg-white/20 bg-transparent"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-white/20 glass-effect rounded-lg shadow-lg">
            <nav className="flex flex-col space-y-1 pt-4 px-2">
              {navigation.map((item) => {
                const isActive =
                  isHomePage && userType !== "admin"
                    ? activeSection === item.href.replace("#", "")
                    : pathname === item.href

                return (
                  <button
                    key={item.name}
                    onClick={() => {
                      if (item.href.startsWith("#")) {
                        scrollToSection(item.href)
                      } else {
                        window.location.href = item.href
                      }
                    }}
                    className={`text-left px-4 py-3 rounded-lg font-medium transition-all duration-300 ${
                      isActive ? "text-gray-900 bg-white/10" : "text-gray-700 hover:text-gray-900 hover:bg-white/10"
                    }`}
                  >
                    {item.name}
                  </button>
                )
              })}
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
