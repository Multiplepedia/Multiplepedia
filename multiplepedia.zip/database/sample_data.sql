-- Additional Sample Data for Visual Creative Project
-- Run this after importing the main database file

USE `visual_creative_project`;

-- Insert more sample portfolio items
INSERT INTO `portfolio_items` (`title`, `slug`, `description`, `category_id`, `client_name`, `project_date`, `image_url`, `tags`, `featured`, `views`, `likes`, `status`, `created_by`) VALUES
('E-commerce Product Shoot', 'ecommerce-product-shoot', 'Professional product photography untuk online store dengan lighting setup yang optimal', 2, 'ShopNow Indonesia', '2024-01-20', '/placeholder.svg?height=300&width=400', '["ecommerce", "product", "lighting"]', 1, 1456, 92, 'published', 1),
('Corporate Event Documentation', 'corporate-event-documentation', 'Dokumentasi lengkap acara corporate dengan multi-angle coverage', 1, 'PT. Global Solutions', '2024-01-18', '/placeholder.svg?height=300&width=400', '["corporate", "event", "documentation"]', 0, 876, 54, 'published', 1),
('Restaurant Menu Design', 'restaurant-menu-design', 'Desain menu restaurant dengan konsep modern dan appetizing food photography', 4, 'Resto Nusantara', '2024-01-12', '/placeholder.svg?height=300&width=400', '["menu", "restaurant", "food"]', 0, 543, 41, 'published', 1),
('Social Media Campaign Video', 'social-media-campaign-video', 'Video campaign untuk social media dengan durasi pendek dan engaging content', 6, 'Brand Lokal', '2024-01-08', '/placeholder.svg?height=300&width=400', '["social-media", "campaign", "short-video"]', 1, 2341, 187, 'published', 1),
('Podcast Video Production', 'podcast-video-production', 'Produksi video podcast dengan multi-camera setup dan professional audio', 1, 'Podcast Indonesia', '2024-01-03', '/placeholder.svg?height=300&width=400', '["podcast", "video", "multi-camera"]', 0, 1234, 78, 'published', 1),
('Fashion Lookbook Photography', 'fashion-lookbook-photography', 'Fashion photography untuk lookbook collection dengan model dan styling', 2, 'Fashion House Jakarta', '2023-12-25', '/placeholder.svg?height=300&width=400', '["fashion", "lookbook", "model"]', 1, 1876, 134, 'published', 1),
('Motion Graphics Animation', 'motion-graphics-animation', 'Animated explainer video dengan motion graphics dan character animation', 3, 'Tech Startup ABC', '2023-12-22', '/placeholder.svg?height=300&width=400', '["motion-graphics", "animation", "explainer"]', 0, 987, 65, 'published', 1),
('Real Estate Virtual Tour', 'real-estate-virtual-tour', 'Virtual tour photography dan video untuk properti premium', 2, 'Premium Properties', '2023-12-18', '/placeholder.svg?height=300&width=400', '["real-estate", "virtual-tour", "property"]', 0, 654, 43, 'published', 1);

-- Insert sample service orders
INSERT INTO `service_orders` (`customer_name`, `customer_email`, `customer_phone`, `service_id`, `service_name`, `project_description`, `budget`, `timeline`, `status`, `priority`) VALUES
('Budi Santoso', 'budi@email.com', '081234567890', 1, 'Video Editing', 'Edit video wedding dengan durasi 10 menit, butuh color grading dan music sync', 'Rp 2.000.000', '1 minggu', 'pending', 'high'),
('Sari Dewi', 'sari@email.com', '081234567891', 3, 'Videography', 'Dokumentasi acara ulang tahun perusahaan, butuh 2 kamera', 'Rp 5.000.000', '2 minggu', 'approved', 'medium'),
('Ahmad Rahman', 'ahmad@email.com', '081234567892', 2, 'Graphic Design', 'Desain logo dan brand identity untuk startup baru', 'Rp 1.500.000', '5 hari', 'in_progress', 'medium'),
('Lisa Permata', 'lisa@email.com', '081234567893', 4, 'Photography', 'Product photography untuk 50 item fashion', 'Rp 3.000.000', '3 hari', 'completed', 'low'),
('Rudi Hartono', 'rudi@email.com', '081234567894', 5, 'Live Streaming', 'Live streaming webinar dengan 3 kamera dan interactive features', 'Rp 8.000.000', '1 hari', 'pending', 'high'),
('Maya Sari', 'maya@email.com', '081234567895', 6, 'Social Media Content', 'Konten Instagram untuk 1 bulan, 20 post dan 10 story', 'Rp 2.500.000', '1 bulan', 'approved', 'medium');

-- Insert sample contact messages
INSERT INTO `contact_messages` (`name`, `email`, `phone`, `subject`, `message`, `service_interest`, `status`, `priority`) VALUES
('John Doe', 'john@email.com', '081234567896', 'Inquiry Wedding Video', 'Halo, saya ingin tanya untuk paket wedding video. Acara saya tanggal 15 Maret 2024. Mohon info lengkapnya.', 'Videography', 'unread', 'high'),
('Jane Smith', 'jane@email.com', '081234567897', 'Logo Design Quote', 'Butuh logo design untuk cafe baru. Budget sekitar 1 juta. Bisa konsultasi dulu?', 'Graphic Design', 'read', 'medium'),
('Michael Johnson', 'michael@email.com', '081234567898', 'Corporate Video Production', 'Perusahaan kami butuh video profil. Durasi sekitar 5 menit dengan interview dan b-roll.', 'Videography', 'replied', 'medium'),
('Sarah Wilson', 'sarah@email.com', '081234567899', 'Product Photography', 'Saya punya online shop fashion. Butuh foto produk untuk 100 item. Berapa estimasi biayanya?', 'Photography', 'unread', 'low'),
('David Brown', 'david@email.com', '081234567800', 'Live Streaming Event', 'Ada event launching produk, butuh live streaming ke YouTube dan Instagram. Tanggal 20 Februari.', 'Live Streaming', 'read', 'high');

-- Insert analytics sample data (last 30 days)
INSERT INTO `analytics` (`page_url`, `page_title`, `visitor_ip`, `device_type`, `browser`, `os`, `created_at`) VALUES
('/', 'Home - Visual Creative Project', '192.168.1.1', 'desktop', 'Chrome', 'Windows', DATE_SUB(NOW(), INTERVAL 1 DAY)),
('/portfolio', 'Portfolio - Visual Creative Project', '192.168.1.2', 'mobile', 'Safari', 'iOS', DATE_SUB(NOW(), INTERVAL 1 DAY)),
('/services', 'Services - Visual Creative Project', '192.168.1.3', 'desktop', 'Firefox', 'macOS', DATE_SUB(NOW(), INTERVAL 2 DAY)),
('/contact', 'Contact - Visual Creative Project', '192.168.1.4', 'tablet', 'Chrome', 'Android', DATE_SUB(NOW(), INTERVAL 2 DAY)),
('/', 'Home - Visual Creative Project', '192.168.1.5', 'desktop', 'Edge', 'Windows', DATE_SUB(NOW(), INTERVAL 3 DAY)),
('/portfolio', 'Portfolio - Visual Creative Project', '192.168.1.6', 'mobile', 'Chrome', 'Android', DATE_SUB(NOW(), INTERVAL 3 DAY)),
('/services', 'Services - Visual Creative Project', '192.168.1.7', 'desktop', 'Chrome', 'Windows', DATE_SUB(NOW(), INTERVAL 4 DAY)),
('/contact', 'Contact - Visual Creative Project', '192.168.1.8', 'mobile', 'Safari', 'iOS', DATE_SUB(NOW(), INTERVAL 4 DAY));

-- Update portfolio views and likes with random data
UPDATE `portfolio_items` SET 
    `views` = FLOOR(RAND() * 3000) + 100,
    `likes` = FLOOR(RAND() * 200) + 10
WHERE `status` = 'published';

-- Create some draft portfolio items for admin testing
INSERT INTO `portfolio_items` (`title`, `slug`, `description`, `category_id`, `client_name`, `project_date`, `image_url`, `tags`, `featured`, `views`, `likes`, `status`, `created_by`) VALUES
('Work in Progress - Fashion Shoot', 'wip-fashion-shoot', 'Fashion photography project yang sedang dalam tahap editing', 2, 'Fashion Brand X', '2024-01-25', '/placeholder.svg?height=300&width=400', '["fashion", "wip", "editing"]', 0, 0, 0, 'draft', 1),
('Upcoming Corporate Video', 'upcoming-corporate-video', 'Video corporate yang akan diproduksi bulan depan', 1, 'Corporate Client Y', '2024-02-01', '/placeholder.svg?height=300&width=400', '["corporate", "upcoming", "video"]', 0, 0, 0, 'draft', 1);

COMMIT;
