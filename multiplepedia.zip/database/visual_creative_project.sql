-- Visual Creative Project Database
-- Database untuk aplikasi portfolio multimedia
-- Created: 2024

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Database: visual_creative_project
CREATE DATABASE IF NOT EXISTS `visual_creative_project` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `visual_creative_project`;

-- --------------------------------------------------------

-- Table structure for table `users`
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  `phone` varchar(20) DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

-- Table structure for table `portfolio_categories`
CREATE TABLE `portfolio_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL UNIQUE,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

-- Table structure for table `portfolio_items`
CREATE TABLE `portfolio_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL UNIQUE,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `project_date` date DEFAULT NULL,
  `image_url` text DEFAULT NULL,
  `video_url` text DEFAULT NULL,
  `gallery_images` json DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `views` int(11) NOT NULL DEFAULT 0,
  `likes` int(11) NOT NULL DEFAULT 0,
  `status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_status` (`status`),
  KEY `idx_featured` (`featured`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `fk_portfolio_category` FOREIGN KEY (`category_id`) REFERENCES `portfolio_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_portfolio_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

-- Table structure for table `services`
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL UNIQUE,
  `description` text NOT NULL,
  `short_description` varchar(500) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `features` json DEFAULT NULL,
  `price_start` decimal(15,2) DEFAULT NULL,
  `price_currency` varchar(10) DEFAULT 'IDR',
  `duration` varchar(100) DEFAULT NULL,
  `popular` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_popular` (`popular`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

-- Table structure for table `service_orders`
CREATE TABLE `service_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL UNIQUE,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `service_name` varchar(255) NOT NULL,
  `project_description` text NOT NULL,
  `budget` varchar(100) DEFAULT NULL,
  `timeline` varchar(100) DEFAULT NULL,
  `status` enum('pending','approved','in_progress','completed','cancelled','rejected') NOT NULL DEFAULT 'pending',
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `notes` text DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_service` (`service_id`),
  KEY `idx_assigned` (`assigned_to`),
  CONSTRAINT `fk_order_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_order_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

-- Table structure for table `contact_messages`
CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `service_interest` varchar(255) DEFAULT NULL,
  `status` enum('unread','read','replied','archived') NOT NULL DEFAULT 'unread',
  `priority` enum('low','medium','high') NOT NULL DEFAULT 'medium',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` int(11) DEFAULT NULL,
  `reply_message` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_replied_by` (`replied_by`),
  CONSTRAINT `fk_message_replied_by` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

-- Table structure for table `site_settings`
CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL UNIQUE,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('text','textarea','number','boolean','json','file') NOT NULL DEFAULT 'text',
  `setting_group` varchar(50) DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

-- Table structure for table `analytics`
CREATE TABLE `analytics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_url` varchar(255) NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `visitor_ip` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `referrer` varchar(255) DEFAULT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `visit_duration` int(11) DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet') DEFAULT NULL,
  `browser` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_page_url` (`page_url`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

-- Insert default data

-- Insert default admin user
INSERT INTO `users` (`name`, `email`, `password`, `role`, `phone`, `status`) VALUES
('Admin', 'admin@visualcreativeproject.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '+62895393181822', 'active');

-- Insert portfolio categories
INSERT INTO `portfolio_categories` (`name`, `slug`, `description`, `icon`, `color`, `sort_order`) VALUES
('Videography', 'videography', 'Professional video production services', 'Video', 'red', 1),
('Photography', 'photography', 'Professional photography services', 'Camera', 'blue', 2),
('Video Editing', 'video-editing', 'Professional video editing and post-production', 'Edit', 'green', 3),
('Graphic Design', 'design', 'Creative graphic design solutions', 'Palette', 'purple', 4),
('Live Streaming', 'live-streaming', 'Professional live streaming services', 'Radio', 'orange', 5),
('Social Media Content', 'social-media', 'Social media content creation', 'Share2', 'pink', 6);

-- Insert services
INSERT INTO `services` (`title`, `slug`, `description`, `short_description`, `icon`, `features`, `price_start`, `duration`, `popular`, `sort_order`) VALUES
('Video Editing', 'video-editing', 'Editing video profesional dengan kualitas cinematic dan storytelling yang menarik', 'Professional video editing with cinematic quality', 'Edit', '["Color Grading Professional", "Motion Graphics & Animation", "Audio Mixing & Sound Design", "Visual Effects & Compositing", "Multi-Camera Editing", "Green Screen & Chroma Key"]', 500000.00, '3-7 hari kerja', 1, 1),
('Graphic Design', 'graphic-design', 'Desain grafis kreatif untuk brand identity, marketing materials, dan digital content', 'Creative graphic design for branding and marketing', 'Palette', '["Logo Design & Branding", "Print Design (Flyer, Poster, Brosur)", "Digital Design (Banner, Social Media)", "Packaging Design", "Corporate Identity", "UI/UX Design"]', 300000.00, '2-5 hari kerja', 0, 2),
('Videography', 'videography', 'Produksi video profesional dengan peralatan canggih dan tim berpengalaman', 'Professional video production with advanced equipment', 'Video', '["Wedding Videography", "Corporate Video", "Event Documentation", "Commercial & Advertisement", "Music Video Production", "Drone Videography"]', 2000000.00, '1-2 minggu', 1, 3),
('Photography', 'photography', 'Jasa fotografi profesional untuk berbagai kebutuhan personal dan komersial', 'Professional photography for personal and commercial needs', 'Camera', '["Portrait & Fashion Photography", "Product Photography", "Event & Wedding Photography", "Corporate Photography", "Food Photography", "Real Estate Photography"]', 1000000.00, '1-3 hari kerja', 0, 4),
('Live Streaming', 'live-streaming', 'Layanan live streaming profesional untuk event, webinar, dan konten digital', 'Professional live streaming for events and digital content', 'Radio', '["Multi-Camera Live Setup", "Professional Audio System", "Real-time Streaming to Multiple Platforms", "Interactive Features", "Technical Support 24/7", "Recording & Post-production"]', 3000000.00, 'Sesuai durasi event', 0, 5),
('Social Media Content', 'social-media-content', 'Konten kreatif dan strategi media sosial untuk meningkatkan engagement brand', 'Creative content and social media strategy', 'Share2', '["Content Strategy & Planning", "Visual Content Creation", "Video Content for Social Media", "Social Media Management", "Influencer Content", "Analytics & Reporting"]', 1500000.00, 'Ongoing', 1, 6);

-- Insert sample portfolio items
INSERT INTO `portfolio_items` (`title`, `slug`, `description`, `category_id`, `client_name`, `project_date`, `image_url`, `tags`, `featured`, `views`, `likes`, `status`, `created_by`) VALUES
('Wedding Cinematic Video - Sarah & John', 'wedding-cinematic-sarah-john', 'Cinematic wedding video dengan drone shots dan storytelling yang emosional', 1, 'Sarah & John', '2024-01-15', '/placeholder.svg?height=300&width=400', '["wedding", "cinematic", "drone"]', 1, 1250, 89, 'published', 1),
('Brand Identity Design - Tech Startup', 'brand-identity-tech-startup', 'Complete brand identity design untuk startup teknologi termasuk logo, business card, dan guidelines', 4, 'TechStart Inc.', '2024-01-10', '/placeholder.svg?height=300&width=400', '["branding", "logo", "identity"]', 0, 890, 67, 'published', 1),
('Corporate Video Production', 'corporate-video-production', 'Video profil perusahaan dengan interview karyawan dan showcase produk', 1, 'PT. Maju Bersama', '2024-01-05', '/placeholder.svg?height=300&width=400', '["corporate", "interview", "product"]', 1, 654, 45, 'published', 1),
('Product Photography - Fashion Brand', 'product-photography-fashion', 'Product photography untuk brand fashion dengan konsep minimalis dan clean', 2, 'Fashion Forward', '2023-12-28', '/placeholder.svg?height=300&width=400', '["product", "fashion", "minimalist"]', 0, 432, 38, 'published', 1),
('Music Video - Local Band', 'music-video-local-band', 'Music video dengan heavy editing, color grading, dan visual effects', 3, 'The Rockers Band', '2023-12-20', '/placeholder.svg?height=300&width=400', '["music", "effects", "color-grading"]', 1, 2100, 156, 'published', 1),
('Live Streaming Setup - Conference', 'live-streaming-conference', 'Multi-camera live streaming setup untuk konferensi internasional', 5, 'Global Conference 2023', '2023-12-15', '/placeholder.svg?height=300&width=400', '["live", "conference", "multi-camera"]', 0, 789, 52, 'published', 1);

-- Insert site settings
INSERT INTO `site_settings` (`setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`) VALUES
('site_name', 'Visual Creative Project', 'text', 'general', 'Website name'),
('site_tagline', 'Creative Multimedia Professional', 'text', 'general', 'Website tagline'),
('site_description', 'Spesialis dalam videografi, fotografi, editing video, dan desain grafis', 'textarea', 'general', 'Website description'),
('contact_email', 'hello@visualcreativeproject.com', 'text', 'contact', 'Primary contact email'),
('contact_phone', '+62 895-3931-81822', 'text', 'contact', 'Primary contact phone'),
('contact_address', 'Jakarta, Indonesia', 'text', 'contact', 'Business address'),
('whatsapp_number', '62895393181822', 'text', 'contact', 'WhatsApp number for orders'),
('social_instagram', '@visualcreativeproject', 'text', 'social', 'Instagram handle'),
('social_linkedin', 'visual-creative-project', 'text', 'social', 'LinkedIn profile'),
('social_youtube', 'VisualCreativeProject', 'text', 'social', 'YouTube channel'),
('social_behance', 'visualcreativeproject', 'text', 'social', 'Behance profile'),
('business_hours', 'Senin - Sabtu, 09:00 - 18:00', 'text', 'general', 'Business operating hours'),
('response_time', '1-2 jam', 'text', 'general', 'Average response time');

-- Create indexes for better performance
CREATE INDEX idx_portfolio_featured_status ON portfolio_items(featured, status);
CREATE INDEX idx_portfolio_category_status ON portfolio_items(category_id, status);
CREATE INDEX idx_orders_status_priority ON service_orders(status, priority);
CREATE INDEX idx_messages_status_created ON contact_messages(status, created_at);
CREATE INDEX idx_analytics_date ON analytics(DATE(created_at));

-- Create triggers for automatic order number generation
DELIMITER $$
CREATE TRIGGER generate_order_number 
BEFORE INSERT ON service_orders 
FOR EACH ROW 
BEGIN 
    IF NEW.order_number IS NULL OR NEW.order_number = '' THEN
        SET NEW.order_number = CONCAT('ORD-', DATE_FORMAT(NOW(), '%Y%m%d'), '-', LPAD(LAST_INSERT_ID() + 1, 4, '0'));
    END IF;
END$$
DELIMITER ;

-- Create view for portfolio statistics
CREATE VIEW portfolio_stats AS
SELECT 
    pc.name as category_name,
    COUNT(pi.id) as total_items,
    SUM(pi.views) as total_views,
    SUM(pi.likes) as total_likes,
    COUNT(CASE WHEN pi.featured = 1 THEN 1 END) as featured_items
FROM portfolio_categories pc
LEFT JOIN portfolio_items pi ON pc.id = pi.category_id AND pi.status = 'published'
GROUP BY pc.id, pc.name;

-- Create view for order statistics
CREATE VIEW order_stats AS
SELECT 
    status,
    priority,
    COUNT(*) as count,
    DATE(created_at) as order_date
FROM service_orders 
GROUP BY status, priority, DATE(created_at);

COMMIT;

-- End of SQL file
-- Import this file to your MySQL/MariaDB database
-- Command: mysql -u username -p database_name < visual_creative_project.sql
